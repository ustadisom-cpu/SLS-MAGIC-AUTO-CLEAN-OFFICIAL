# -*- coding: utf-8 -*-
"""
SLS MAGIC - popup (floating window) untuk menu GEOREFERENCE:
  * RenameDialog : ganti nama gambar berdasarkan TXT
  * JgwDialog    : INSERT JGW dari 1 folder ke folder tujuan berdasarkan nama di TXT

Logika file ada di georef_tools.py (tanpa Qt) agar mudah diuji.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QBrush, QColor
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QFileDialog,
    QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
    QMessageBox, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from . import georef_tools as gt

_GREEN = QColor('#0f6f3e')
_GREY = QColor('#667085')
_AMBER = QColor('#b54708')
_RED = QColor('#b42318')


def _status_color(status, ok):
    s = status.upper()
    if ok:
        return _AMBER if 'MIRIP' in s or 'UPDATE' in s else _GREEN
    if s.startswith('SUDAH'):
        return _GREY
    return _RED


class _BaseToolDialog(QDialog):
    """Kerangka popup: header, form, tabel hasil, baris tombol, progress."""

    TITLE = ''
    SUBTITLE = ''

    def __init__(self, parent, state):
        super().__init__(parent)
        self.state = state
        self.setWindowTitle(self.TITLE)
        self.setWindowFlags(Qt.Window | Qt.WindowCloseButtonHint | Qt.WindowMinMaxButtonsHint)
        self.setModal(False)
        self.resize(1040, 700)
        self.setMinimumSize(760, 520)
        self._form_rows = {}
        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(12, 10, 12, 10)
        self._root.setSpacing(8)

        head = QFrame()
        head.setObjectName('workspaceCard')
        hl = QVBoxLayout(head)
        hl.setContentsMargins(14, 10, 14, 10)
        hl.setSpacing(2)
        t = QLabel(self.TITLE)
        t.setObjectName('georefTitle')
        s = QLabel(self.SUBTITLE)
        s.setObjectName('georefSubtitle')
        s.setWordWrap(True)
        hl.addWidget(t)
        hl.addWidget(s)
        self._root.addWidget(head)

        self._form = QGridLayout()
        self._form.setHorizontalSpacing(8)
        self._form.setVerticalSpacing(6)
        self._form.setColumnStretch(1, 1)
        self._root.addLayout(self._form)
        self._form_row = 0
        self.state.add_listener(self._on_state_changed)

    # ---------- helper form ----------
    def _add_path_row(self, key, label, button_text, slot, placeholder=''):
        lab = QLabel(label)
        edit = QLineEdit()
        edit.setReadOnly(True)
        edit.setMinimumHeight(30)
        edit.setPlaceholderText(placeholder)
        btn = QPushButton(button_text)
        btn.setMinimumHeight(30)
        btn.clicked.connect(slot)
        r = self._form_row
        self._form.addWidget(lab, r, 0)
        self._form.addWidget(edit, r, 1)
        self._form.addWidget(btn, r, 2)
        self._form_row += 1
        self._form_rows[key] = (lab, edit, btn)
        return edit

    def _add_combo_row(self, key, label, entries, slot=None):
        lab = QLabel(label)
        combo = QComboBox()
        combo.setMinimumHeight(30)
        for text, data in entries:
            combo.addItem(text, data)
        if slot is not None:
            combo.currentIndexChanged.connect(slot)
        r = self._form_row
        self._form.addWidget(lab, r, 0)
        self._form.addWidget(combo, r, 1, 1, 2)
        self._form_row += 1
        self._form_rows[key] = (lab, combo, None)
        return combo

    def _add_check_row(self, checks):
        """checks: [(key, text, checked)] -> satu baris horizontal."""
        box = QWidget()
        hl = QHBoxLayout(box)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(16)
        out = {}
        for key, text, checked in checks:
            cb = QCheckBox(text)
            cb.setChecked(checked)
            hl.addWidget(cb)
            out[key] = cb
        hl.addStretch(1)
        self._form.addWidget(box, self._form_row, 0, 1, 3)
        self._form_row += 1
        return out

    def _show_row(self, key, visible):
        lab, w, btn = self._form_rows[key]
        for x in (lab, w, btn):
            if x is not None:
                x.setVisible(visible)

    def _build_table(self, headers, widths):
        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.verticalHeader().setVisible(False)
        hh = self.table.horizontalHeader()
        try:
            for i, w in enumerate(widths):
                if w == 0:
                    hh.setSectionResizeMode(i, QHeaderView.Stretch)
                else:
                    hh.setSectionResizeMode(i, QHeaderView.Interactive)
                    self.table.setColumnWidth(i, w)
        except Exception:
            pass
        self._root.addWidget(self.table, 1)

    def _build_footer(self, buttons):
        """buttons: [(attr, text, slot, object_name_or_None)] ; return layout."""
        self.summary = QLabel('')
        self.summary.setObjectName('toolboxNote')
        self.summary.setWordWrap(True)
        self._root.addWidget(self.summary)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedHeight(8)
        self.progress.setTextVisible(False)
        self._root.addWidget(self.progress)
        row = QHBoxLayout()
        row.setSpacing(7)
        for attr, text, slot, obj in buttons:
            if attr == '|':
                row.addStretch(1)
                continue
            b = QPushButton(text)
            b.setMinimumHeight(34)
            if obj:
                b.setObjectName(obj)
            b.clicked.connect(slot)
            setattr(self, attr, b)
            row.addWidget(b)
        self._root.addLayout(row)

    # ---------- umum ----------
    def _set_progress(self, v):
        self.progress.setValue(max(0, min(100, int(v))))
        QApplication.processEvents()

    def _pick_txt(self):
        start = os.path.dirname(self.state.path) if self.state.path else ''
        path, _ = QFileDialog.getOpenFileName(self, 'Pilih FILE TXT pemetaan', start,
                                              'Text Files (*.txt *.csv);;All Files (*)')
        if not path:
            return
        try:
            rows = self.state.load(path)
        except Exception as e:
            QMessageBox.critical(self, self.TITLE, 'TXT gagal dibaca:\n{}'.format(e))
            return
        if not rows:
            QMessageBox.warning(self, self.TITLE, 'TXT tidak memiliki baris pemetaan yang valid.')

    def _pick_dir_into(self, edit, title):
        start = edit.text().strip() or (os.path.dirname(self.state.path) if self.state.path else '')
        path = QFileDialog.getExistingDirectory(self, title, start)
        if path:
            edit.setText(os.path.normpath(path))
            self.scan()

    def _txt_status_text(self):
        if not self.state.rows:
            return 'Belum ada TXT.'
        return '{} baris pemetaan'.format(len(self.state.rows))

    def _on_state_changed(self):
        try:
            self._sync_txt_widgets()
            self.scan()
        except RuntimeError:
            pass  # widget sudah dihapus

    def showEvent(self, event):
        try:
            self._sync_txt_widgets()
        except Exception:
            pass
        super().showEvent(event)

    def _checked_rows(self):
        rows = []
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 0)
            if it is not None and it.checkState() == Qt.Checked and not self.table.isRowHidden(r):
                rows.append(r)
        return rows

    def _set_checks(self, only_ready):
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 0)
            if it is None:
                continue
            ok = bool(self._row_ok(r))
            it.setCheckState(Qt.Checked if (only_ready and ok) else Qt.Unchecked)
        self.table.blockSignals(False)

    def _apply_filter(self, text):
        text = (text or '').strip().lower()
        for r in range(self.table.rowCount()):
            if not text:
                self.table.setRowHidden(r, False)
                continue
            hit = False
            for c in range(1, self.table.columnCount()):
                it = self.table.item(r, c)
                if it is not None and text in it.text().lower():
                    hit = True
                    break
            self.table.setRowHidden(r, not hit)

    @staticmethod
    def _cell(text, tooltip=None, color=None, bold=False):
        it = QTableWidgetItem(text)
        if tooltip:
            it.setToolTip(tooltip)
        if color is not None:
            it.setForeground(QBrush(color))
        if bold:
            f = it.font()
            f.setBold(True)
            it.setFont(f)
        return it

    def _check_cell(self, ok):
        it = QTableWidgetItem('')
        if ok:
            it.setFlags((it.flags() | Qt.ItemIsUserCheckable) & ~Qt.ItemIsEditable)
            it.setCheckState(Qt.Checked)
        else:
            it.setFlags(it.flags() & ~Qt.ItemIsUserCheckable & ~Qt.ItemIsEditable)
        return it


# ======================================================================
# INSERT JGW
# ======================================================================
class JgwDialog(_BaseToolDialog):
    TITLE = 'INSERT JGW'
    SUBTITLE = ('Ambil file .jgw dari 1 folder sumber, lalu tempatkan ke folder yang ditentukan '
                'berdasarkan nama di TXT. Pencarian nama JGW memakai kolom 2 TXT (lalu kolom 1). '
                'Klik 2x pada baris untuk memilih target / folder tujuan secara manual.')

    def __init__(self, parent, state):
        super().__init__(parent, state)
        self.items = []
        self.target_overrides = {}
        self.dest_overrides = {}

        self.txt_edit = self._add_path_row('txt', '① File TXT', 'Pilih TXT…', self._pick_txt,
                                           'Format: nama_kolom1 | nama_kolom2')
        self.src_edit = self._add_path_row('src', '② Folder sumber JGW', 'Pilih…',
                                           lambda: self._pick_dir_into(self.src_edit, 'Pilih FOLDER SUMBER JGW'))
        self.mode_combo = self._add_combo_row('mode', '③ Tujuan JGW', [
            ('Di samping raster target (cari raster sesuai TXT)', 'beside'),
            ('Semua ke 1 folder tujuan', 'flat'),
            ('Ke sub-folder yang namanya sesuai TXT', 'subfolder'),
        ], self._mode_changed)
        self.target_edit = self._add_path_row('target', '   Folder raster target', 'Pilih…',
                                              lambda: self._pick_dir_into(self.target_edit, 'Pilih FOLDER RASTER TARGET'),
                                              'Folder tempat gambar/raster berada (dicari rekursif)')
        self.dest_edit = self._add_path_row('dest', '   Folder tujuan', 'Pilih…',
                                            lambda: self._pick_dir_into(self.dest_edit, 'Pilih FOLDER TUJUAN'),
                                            'Folder tujuan JGW')
        self.name_combo = self._add_combo_row('name', '④ Nama file JGW hasil', [
            ('Sama dengan raster target (jika tidak ada: nama kolom 1)', 'target'),
            ('Nama kolom 1 TXT', 'col1'),
            ('Nama kolom 2 TXT', 'col2'),
            ('Nama asli file JGW sumber', 'asli'),
        ], lambda *_: self.scan())
        self.folderkey_combo = self._add_combo_row('fkey', '   Nama folder tujuan', [
            ('Mengikuti kolom 1 TXT', 'col1'),
            ('Mengikuti kolom 2 TXT', 'col2'),
        ], lambda *_: self.scan())
        self.opts = self._add_check_row([
            ('overwrite', 'Timpa JGW lama jika isinya berbeda', True),
            ('mkdir', 'Buat sub-folder jika belum ada', False),
            ('recursive', 'Cari rekursif ke dalam sub-folder', True),
        ])
        for cb in self.opts.values():
            cb.stateChanged.connect(lambda *_: self.scan())

        self.search = QLineEdit()
        self.search.setPlaceholderText('🔍 Cari / filter baris…')
        self.search.setMinimumHeight(28)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._apply_filter)
        self._root.addWidget(self.search)

        self._build_table(['✓', '#', 'TXT KOLOM 1', 'TXT KOLOM 2', 'JGW SUMBER', 'TUJUAN JGW', 'STATUS'],
                          [34, 44, 0, 0, 0, 0, 190])
        self.table.cellDoubleClicked.connect(self._on_double_click)
        self._build_footer([
            ('btn_scan', '↻  Scan ulang', self.scan, None),
            ('btn_all', '✓  Pilih yang siap', lambda: self._set_checks(True), None),
            ('btn_none', '□  Kosongkan', lambda: self._set_checks(False), None),
            ('|', '', None, None),
            ('btn_run', '✓  INSERT JGW (yang dicentang)', self.run, 'geoImportButton'),
        ])
        self._mode_changed()
        self._sync_txt_widgets()

    # ---------- state ----------
    def _sync_txt_widgets(self):
        self.txt_edit.setText(self.state.path)

    def _mode(self):
        return self.mode_combo.itemData(self.mode_combo.currentIndex()) or 'beside'

    def _mode_changed(self, *_):
        m = self._mode()
        self._show_row('target', True)
        self._show_row('dest', m in ('flat', 'subfolder'))
        self._show_row('fkey', m == 'subfolder')
        self.opts['mkdir'].setVisible(m == 'subfolder')
        lab = self._form_rows['target'][0]
        lab.setText('   Folder raster target' if m == 'beside' else '   Folder raster target (opsional)')
        self.target_overrides = {}
        self.dest_overrides = {}
        self.scan()

    # ---------- scan ----------
    def _row_ok(self, r):
        return r < len(self.items) and self.items[r].ok

    def scan(self, *_):
        if not hasattr(self, 'table'):
            return
        self.table.setRowCount(0)
        self.items = []
        mapping = self.state.rows
        jgw = self.src_edit.text().strip()
        mode = self._mode()
        if not mapping:
            self.summary.setText('Pilih file TXT terlebih dahulu.')
            return
        if not jgw or not os.path.isdir(jgw):
            self.summary.setText('Pilih FOLDER SUMBER JGW.')
            return
        if mode == 'beside' and not (self.target_edit.text().strip() and os.path.isdir(self.target_edit.text().strip())):
            self.summary.setText('Mode "di samping raster target": pilih FOLDER RASTER TARGET.')
            return
        if mode in ('flat', 'subfolder') and not (self.dest_edit.text().strip() and os.path.isdir(self.dest_edit.text().strip())):
            self.summary.setText('Pilih FOLDER TUJUAN.')
            return
        try:
            self.items = gt.plan_jgw(
                mapping, jgw, mode=mode,
                target_folder=self.target_edit.text().strip(),
                dest_folder=self.dest_edit.text().strip(),
                name_mode=self.name_combo.itemData(self.name_combo.currentIndex()) or 'target',
                folder_key=self.folderkey_combo.itemData(self.folderkey_combo.currentIndex()) or 'col1',
                create_folders=self.opts['mkdir'].isChecked(),
                overwrite=self.opts['overwrite'].isChecked(),
                recursive=self.opts['recursive'].isChecked(),
                target_overrides=self.target_overrides,
                dest_overrides=self.dest_overrides)
        except Exception as e:
            self.summary.setText('Scan gagal: {}'.format(e))
            return
        self._fill_table()

    def _fill_table(self):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.items))
        ready = same = bad = 0
        for r, it in enumerate(self.items):
            self.table.setItem(r, 0, self._check_cell(it.ok))
            self.table.setItem(r, 1, self._cell(str(r + 1)))
            self.table.setItem(r, 2, self._cell(it.c1, it.target or it.c1))
            self.table.setItem(r, 3, self._cell(it.c2))
            self.table.setItem(r, 4, self._cell(os.path.basename(it.src) if it.src else '-', it.src))
            self.table.setItem(r, 5, self._cell(it.dst or '-', it.note or it.dst))
            self.table.setItem(r, 6, self._cell(it.status, it.note, _status_color(it.status, it.ok), True))
            if it.ok:
                ready += 1
            elif it.status.startswith('SUDAH'):
                same += 1
            else:
                bad += 1
        self.table.blockSignals(False)
        self._apply_filter(self.search.text())
        self.summary.setText('{} baris TXT  •  SIAP: {}  •  SUDAH SAMA: {}  •  PERLU DICEK: {}'.format(
            len(self.items), ready, same, bad))

    # ---------- manual ----------
    def _on_double_click(self, row, col):
        if row >= len(self.items):
            return
        it = self.items[row]
        mode = self._mode()
        if mode == 'beside':
            start = self.target_edit.text().strip()
            path, _ = QFileDialog.getOpenFileName(
                self, 'Pilih RASTER TARGET untuk baris #{} ({})'.format(row + 1, it.c1), start,
                'Raster (*.jpg *.jpeg *.png *.tif *.tiff *.bmp);;All Files (*)')
            if path:
                self.target_overrides[row] = os.path.normpath(path)
                self.scan()
        else:
            start = self.dest_edit.text().strip()
            path = QFileDialog.getExistingDirectory(
                self, 'Pilih FOLDER TUJUAN untuk baris #{} ({})'.format(row + 1, it.c1), start)
            if path:
                self.dest_overrides[row] = os.path.normpath(path)
                self.scan()

    # ---------- jalankan ----------
    def run(self):
        rows = [r for r in self._checked_rows() if self._row_ok(r)]
        if not rows:
            QMessageBox.information(self, self.TITLE, 'Tidak ada baris SIAP yang dicentang.')
            return
        if QMessageBox.question(
                self, self.TITLE,
                'Salin {} file JGW ke folder tujuan?\n(JGW lama yang berbeda akan {}.)'.format(
                    len(rows), 'DITIMPA' if self.opts['overwrite'].isChecked() else 'dibiarkan')
        ) != QMessageBox.Yes:
            return
        chosen = []
        for r in rows:
            chosen.append(self.items[r])
        keep = {id(x) for x in chosen}
        for it in self.items:                      # hanya yang dicentang yang dieksekusi
            if id(it) not in keep:
                it.ok = False
        report_folder = (self.dest_edit.text().strip() if self._mode() != 'beside'
                         else self.target_edit.text().strip())
        res = gt.execute_jgw(self.items, report_folder=report_folder, progress=self._set_progress)
        self._set_progress(100)
        msg = 'Selesai.\n\nBaru: {}\nDiperbarui: {}\nError: {}'.format(
            res['copied'], res['updated'], len(res['errors']))
        if res['report_path']:
            msg += '\n\nLaporan CSV:\n{}'.format(res['report_path'])
        if res['errors']:
            QMessageBox.warning(self, self.TITLE, msg + '\n\n' + '\n'.join(res['errors'][:15]))
        else:
            QMessageBox.information(self, self.TITLE, msg)
        self._set_progress(0)
        self.scan()


# ======================================================================
# RENAME GAMBAR
# ======================================================================
class RenameDialog(_BaseToolDialog):
    TITLE = 'RENAME GAMBAR'
    SUBTITLE = ('Aplikasi mengidentifikasi nama file gambar di folder (huruf besar/kecil, spasi, dan '
                'ekstensi diabaikan), lalu mengganti namanya mengikuti TXT. Pratinjau lengkap sebelum '
                'proses, ada log UNDO. Ekstensi asli file dipertahankan.')

    def __init__(self, parent, state):
        super().__init__(parent, state)
        self.items = []
        self.unlisted = []
        self.last_log = ''

        self.txt_edit = self._add_path_row('txt', '① File TXT', 'Pilih TXT…', self._pick_txt,
                                           'Format: nama_lama | nama_baru')
        self.img_edit = self._add_path_row('img', '② Folder gambar', 'Pilih…',
                                           lambda: self._pick_dir_into(self.img_edit, 'Pilih FOLDER GAMBAR'))
        self.dir_combo = self._add_combo_row('dir', '③ Arah penamaan', [
            ('Kolom 1 TXT  →  Kolom 2 TXT   (nama baru = kolom 2)', '1to2'),
            ('Kolom 2 TXT  →  Kolom 1 TXT   (kebalikan)', '2to1'),
        ], lambda *_: self.scan())
        self.mode_combo = self._add_combo_row('mode', '④ Mode', [
            ('Ganti nama di tempat (ada log UNDO)', 'rename'),
            ('Salin dengan nama baru ke folder lain (file asli aman)', 'copy'),
        ], self._mode_changed)
        self.out_edit = self._add_path_row('out', '   Folder hasil salinan', 'Pilih…',
                                           lambda: self._pick_dir_into(self.out_edit, 'Pilih FOLDER HASIL'),
                                           'Folder tujuan salinan')
        self.opts = self._add_check_row([
            ('sidecar', 'Ikut ganti nama file pendamping (.jgw, .prj, .aux.xml, dll.)', True),
            ('loose', 'Kenali nama mirip (abaikan spasi/huruf besar/simbol)', True),
            ('recursive', 'Cari rekursif ke sub-folder', True),
        ])
        for cb in self.opts.values():
            cb.stateChanged.connect(lambda *_: self.scan())

        self.search = QLineEdit()
        self.search.setPlaceholderText('🔍 Cari / filter baris…')
        self.search.setMinimumHeight(28)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._apply_filter)
        self._root.addWidget(self.search)

        self._build_table(['✓', '#', 'NAMA LAMA (TXT)', 'NAMA BARU', 'FILE TERDETEKSI', 'STATUS'],
                          [34, 44, 0, 0, 0, 200])
        self._build_footer([
            ('btn_scan', '↻  Scan ulang', self.scan, None),
            ('btn_all', '✓  Pilih yang siap', lambda: self._set_checks(True), None),
            ('btn_none', '□  Kosongkan', lambda: self._set_checks(False), None),
            ('btn_unlisted', '🖼  Gambar di luar TXT…', self._show_unlisted, None),
            ('|', '', None, None),
            ('btn_undo', '↶  UNDO dari log…', self.undo, None),
            ('btn_run', '✎  RENAME (yang dicentang)', self.run, 'geoImportButton'),
        ])
        self._mode_changed()
        self._sync_txt_widgets()

    def _sync_txt_widgets(self):
        self.txt_edit.setText(self.state.path)

    def _mode(self):
        return self.mode_combo.itemData(self.mode_combo.currentIndex()) or 'rename'

    def _mode_changed(self, *_):
        self._show_row('out', self._mode() == 'copy')
        self.scan()

    def _row_ok(self, r):
        return r < len(self.items) and self.items[r].ok

    def scan(self, *_):
        if not hasattr(self, 'table'):
            return
        self.table.setRowCount(0)
        self.items = []
        self.unlisted = []
        folder = self.img_edit.text().strip()
        if not self.state.rows:
            self.summary.setText('Pilih file TXT terlebih dahulu.')
            return
        if not folder or not os.path.isdir(folder):
            self.summary.setText('Pilih FOLDER GAMBAR.')
            return
        out = None
        if self._mode() == 'copy':
            out = self.out_edit.text().strip()
            if not out:
                self.summary.setText('Pilih FOLDER HASIL untuk mode salin.')
                return
        try:
            self.items, self.unlisted = gt.plan_rename(
                self.state.rows, folder,
                recursive=self.opts['recursive'].isChecked(),
                direction=self.dir_combo.itemData(self.dir_combo.currentIndex()) or '1to2',
                with_sidecars=self.opts['sidecar'].isChecked(),
                loose=self.opts['loose'].isChecked(),
                out_folder=out)
        except Exception as e:
            self.summary.setText('Scan gagal: {}'.format(e))
            return
        self._fill_table(folder)

    def _fill_table(self, folder):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.items))
        ready = bad = same = 0
        for r, it in enumerate(self.items):
            self.table.setItem(r, 0, self._check_cell(it.ok))
            self.table.setItem(r, 1, self._cell(str(r + 1)))
            self.table.setItem(r, 2, self._cell(it.txt_old))
            self.table.setItem(r, 3, self._cell(it.new_name or it.txt_new,
                                                 'Ekstensi asli dipertahankan'))
            if it.src:
                extra = ' (+{} pendamping)'.format(len(it.sidecars)) if it.sidecars else ''
                self.table.setItem(r, 4, self._cell(os.path.relpath(it.src, folder) + extra, it.src))
            else:
                self.table.setItem(r, 4, self._cell('-', it.note))
            self.table.setItem(r, 5, self._cell(it.status, it.note, _status_color(it.status, it.ok), True))
            if it.ok:
                ready += 1
            elif it.status.startswith('SUDAH'):
                same += 1
            else:
                bad += 1
        self.table.blockSignals(False)
        self._apply_filter(self.search.text())
        self.summary.setText(
            '{} baris TXT  •  SIAP: {}  •  SUDAH SESUAI: {}  •  PERLU DICEK: {}  •  Gambar di luar TXT: {}'.format(
                len(self.items), ready, same, bad, len(self.unlisted)))

    def _show_unlisted(self):
        dlg = QDialog(self)
        dlg.setWindowTitle('Gambar yang tidak ada di TXT')
        dlg.resize(560, 420)
        lay = QVBoxLayout(dlg)
        lab = QLabel('{} gambar di folder tidak tercantum di TXT (tidak akan diubah):'.format(len(self.unlisted)))
        lab.setWordWrap(True)
        lay.addWidget(lab)
        lst = QListWidget()
        base = self.img_edit.text().strip()
        for p in self.unlisted:
            lst.addItem(os.path.relpath(p, base) if base else p)
        lay.addWidget(lst, 1)
        btn = QPushButton('Tutup')
        btn.clicked.connect(dlg.accept)
        lay.addWidget(btn)
        dlg.exec_() if hasattr(dlg, 'exec_') else dlg.exec()

    def run(self):
        rows = [r for r in self._checked_rows() if self._row_ok(r)]
        if not rows:
            QMessageBox.information(self, self.TITLE, 'Tidak ada baris SIAP yang dicentang.')
            return
        mode = self._mode()
        verb = 'ganti nama' if mode == 'rename' else 'salin dengan nama baru'
        if QMessageBox.question(self, self.TITLE,
                                'Lanjut {} {} gambar?{}'.format(
                                    verb, len(rows),
                                    '\n\nLog UNDO akan disimpan di folder gambar.' if mode == 'rename' else '')
                                ) != QMessageBox.Yes:
            return
        keep = {id(self.items[r]) for r in rows}
        for it in self.items:
            if id(it) not in keep:
                it.ok = False
        log_folder = self.img_edit.text().strip() if mode == 'rename' else self.out_edit.text().strip()
        res = gt.execute_rename(self.items, mode=mode, log_folder=log_folder, progress=self._set_progress)
        self._set_progress(100)
        if res['log_path']:
            self.last_log = res['log_path']
        msg = 'Selesai.\n\nGambar diproses: {}\nTotal file (termasuk pendamping): {}\nError: {}'.format(
            res['files'], res['done'], len(res['errors']))
        if res['log_path'] and mode == 'rename':
            msg += '\n\nLog UNDO:\n{}'.format(res['log_path'])
        if res['errors']:
            QMessageBox.warning(self, self.TITLE, msg + '\n\n' + '\n'.join(res['errors'][:15]))
        else:
            QMessageBox.information(self, self.TITLE, msg)
        self._set_progress(0)
        self.scan()

    def undo(self):
        start = self.last_log or self.img_edit.text().strip()
        path, _ = QFileDialog.getOpenFileName(self, 'Pilih log rename (SLS_RENAME_LOG_*.json)', start,
                                              'Log rename (SLS_RENAME_LOG_*.json *.json)')
        if not path:
            return
        try:
            restored, errors = gt.undo_rename(path)
        except Exception as e:
            QMessageBox.critical(self, self.TITLE, 'Log tidak bisa dibaca:\n{}'.format(e))
            return
        msg = 'File dikembalikan: {}\nError: {}'.format(restored, len(errors))
        if errors:
            QMessageBox.warning(self, self.TITLE, msg + '\n\n' + '\n'.join(errors[:15]))
        else:
            QMessageBox.information(self, self.TITLE, msg)
        self.scan()
