# -*- coding: utf-8 -*-
"""
SLS MAGIC - logika file untuk menu GEOREFERENCE (tanpa dependensi Qt/QGIS).

Berisi:
  * parse_mapping   : baca TXT pemetaan (kolom 1 -> kolom 2)
  * RENAME gambar   : plan_rename / execute_rename / undo_rename
  * INSERT JGW      : plan_jgw / execute_jgw

Dipisahkan dari UI supaya mudah diuji dan tidak mengubah script lama.
"""
import csv
import json
import os
import re
import shutil
from datetime import datetime

IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.tif', '.tiff', '.bmp')
# Ekstensi file pendamping raster yang ikut diganti namanya.
SIDECAR_EXTS = ('.jgw', '.jpw', '.wld', '.pgw', '.tfw', '.bpw', '.prj', '.aux.xml',
                '.xml', '.ovr', '.msk', '.rrd', '.qml', '.qmd')
_INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_HEADER_LEFT = ('nama', 'target', 'target_file', 'file_target', 'file', 'lama', 'nama_lama')
_HEADER_RIGHT = ('sumber', 'source', 'source_file', 'file_sumber', 'baru', 'nama_baru')


# ------------------------------------------------------------------
# Util nama
# ------------------------------------------------------------------
def split_ext(name):
    """('Peta0192', '.jpg') ; ekstensi hanya jika termasuk IMAGE_EXTS/.jgw."""
    base = os.path.basename(str(name)).strip()
    low = base.lower()
    for ext in IMAGE_EXTS + ('.jgw',):
        if low.endswith(ext):
            return base[:-len(ext)], base[-len(ext):]
    return base, ''


def norm_key(name):
    """Kunci pencocokan longgar: tanpa ekstensi, huruf kecil, hanya a-z0-9."""
    stem, _ = split_ext(name)
    # '.jpg.jgw' -> buang lapis kedua
    stem, _ = split_ext(stem)
    return re.sub(r'[^a-z0-9]', '', stem.lower())


def safe_filename(name):
    cleaned = _INVALID_CHARS.sub('_', str(name)).strip().strip('.')
    return cleaned


def _read_text(path):
    for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            with open(path, 'r', encoding=enc) as fh:
                return fh.read()
        except UnicodeDecodeError:
            continue
    with open(path, 'r', encoding='utf-8', errors='replace') as fh:
        return fh.read()


# ------------------------------------------------------------------
# TXT mapping
# ------------------------------------------------------------------
def parse_mapping(path):
    """
    Baca TXT. Pemisah yang dikenali (urut prioritas):  |   TAB   ;   ,   -> / =>   2+ spasi
    Baris dengan satu nama saja dianggap (nama, nama).
    Baris kosong dan baris berawalan # dilewati. Header umum dilewati.
    Return: list[(kolom1, kolom2)]
    """
    rows = []
    for raw in _read_text(path).splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        parts = None
        for sep in ('|', '\t', ';', ','):
            if sep in line:
                parts = line.split(sep, 1)
                break
        if parts is None:
            m = re.split(r'\s*(?:=>|->|→)\s*', line, maxsplit=1)
            if len(m) == 2:
                parts = m
        if parts is None:
            m = re.split(r'\s{2,}', line, maxsplit=1)
            if len(m) == 2:
                parts = m
        if parts is None:
            toks = line.split()
            parts = toks if len(toks) == 2 else [line, line]
        left = parts[0].strip().strip('"').strip("'").strip()
        right = parts[1].strip().strip('"').strip("'").strip()
        if not left:
            continue
        if not right:
            right = left
        if left.lower() in _HEADER_LEFT and right.lower() in _HEADER_RIGHT:
            continue
        rows.append((left, right))
    return rows


class MappingState(object):
    """TXT mapping yang dipakai bersama oleh popup RENAME dan INSERT JGW."""

    def __init__(self):
        self.path = ''
        self.rows = []
        self._listeners = []

    def add_listener(self, fn):
        if fn not in self._listeners:
            self._listeners.append(fn)

    def load(self, path):
        rows = parse_mapping(path)
        self.path = os.path.normpath(path)
        self.rows = rows
        for fn in list(self._listeners):
            try:
                fn()
            except Exception:
                pass
        return rows


# ------------------------------------------------------------------
# Scan folder
# ------------------------------------------------------------------
def walk_files(folder, exts, recursive=True):
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    if recursive:
        for root, dirs, names in os.walk(folder):
            dirs.sort(key=str.lower)
            for fn in sorted(names, key=str.lower):
                if fn.lower().endswith(exts):
                    out.append(os.path.normpath(os.path.join(root, fn)))
    else:
        for fn in sorted(os.listdir(folder), key=str.lower):
            p = os.path.join(folder, fn)
            if os.path.isfile(p) and fn.lower().endswith(exts):
                out.append(os.path.normpath(p))
    return out


class FileIndex(object):
    """Indeks file: persis (nama.lower) dan longgar (norm_key)."""

    def __init__(self, paths):
        self.paths = list(paths)
        self.exact = {}
        self.loose = {}
        for p in self.paths:
            fn = os.path.basename(p).lower()
            self.exact.setdefault(fn, []).append(p)
            self.loose.setdefault(norm_key(fn), []).append(p)

    def find(self, name, allow_loose=True):
        """Return (list_path, kind) ; kind: 'exact' | 'loose' | ''."""
        fn = os.path.basename(str(name)).strip().lower()
        hit = self.exact.get(fn)
        if hit:
            return list(hit), 'exact'
        # nama tanpa ekstensi di TXT -> cocokkan terhadap stem
        key = norm_key(fn)
        if allow_loose and key:
            hit = self.loose.get(key)
            if hit:
                return list(hit), 'loose'
        return [], ''


def _same_content(a, b):
    try:
        if os.path.getsize(a) != os.path.getsize(b):
            return False
        with open(a, 'rb') as fa, open(b, 'rb') as fb:
            return fa.read() == fb.read()
    except Exception:
        return False


def _timestamp():
    return datetime.now().strftime('%Y%m%d_%H%M%S')


# ------------------------------------------------------------------
# RENAME GAMBAR
# ------------------------------------------------------------------
class RenameItem(object):
    __slots__ = ('row', 'txt_old', 'txt_new', 'src', 'new_name', 'dst',
                 'status', 'ok', 'kind', 'sidecars', 'note')

    def __init__(self, row, txt_old, txt_new):
        self.row = row
        self.txt_old = txt_old
        self.txt_new = txt_new
        self.src = ''
        self.new_name = ''
        self.dst = ''
        self.status = ''
        self.ok = False
        self.kind = ''
        self.sidecars = []
        self.note = ''


def find_sidecars(src_path):
    """File pendamping di folder yang sama, dengan nama sama: [(path, sisa_nama)]."""
    folder = os.path.dirname(src_path)
    base = os.path.basename(src_path)
    stem, _ = os.path.splitext(base)
    base_l, stem_l = base.lower(), stem.lower()
    found = []
    try:
        names = os.listdir(folder)
    except Exception:
        return found
    for fn in names:
        low = fn.lower()
        if low == base_l:
            continue
        p = os.path.join(folder, fn)
        if not os.path.isfile(p):
            continue
        # contoh: Peta0192.jpg.aux.xml  (awalan = nama lengkap)
        if low.startswith(base_l + '.'):
            found.append((p, fn[len(stem):]))     # '.jpg.aux.xml'
            continue
        # contoh: Peta0192.jgw / Peta0192.prj (awalan = stem)
        if low.startswith(stem_l + '.'):
            rest = low[len(stem_l):]
            if rest in SIDECAR_EXTS:
                found.append((p, fn[len(stem):]))
    return found


def plan_rename(mapping, folder, recursive=True, direction='1to2', with_sidecars=True,
                loose=True, out_folder=None):
    """
    mapping   : [(kolom1, kolom2)]
    direction : '1to2' (nama kolom 1 -> kolom 2) atau '2to1'
    out_folder: bila diisi (mode salin) file baru ditaruh di sini, struktur sub-folder dijaga.
    Return (items, unlisted) ; unlisted = gambar di folder yang tidak ada di TXT.
    """
    images = walk_files(folder, IMAGE_EXTS, recursive)
    index = FileIndex(images)
    items = []
    used_images = set()
    for i, (c1, c2) in enumerate(mapping):
        old, new = (c1, c2) if direction == '1to2' else (c2, c1)
        it = RenameItem(i, old, new)
        items.append(it)
        found, kind = index.find(old, allow_loose=loose)
        if not found:
            it.status = 'GAMBAR TIDAK DITEMUKAN'
            continue
        if len(found) > 1:
            it.status = 'DUPLIKAT • {} FILE'.format(len(found))
            it.note = '; '.join(found)
            continue
        it.src = found[0]
        it.kind = kind
        used_images.add(it.src)
        src_stem, src_ext = os.path.splitext(os.path.basename(it.src))
        new_stem, _ = split_ext(new)
        new_stem = safe_filename(new_stem)
        if not new_stem:
            it.status = 'NAMA BARU KOSONG'
            continue
        it.new_name = new_stem + src_ext          # ekstensi asli dipertahankan
        dst_dir = os.path.dirname(it.src)
        if out_folder:
            rel = os.path.relpath(dst_dir, folder)
            dst_dir = out_folder if rel == '.' else os.path.join(out_folder, rel)
        it.dst = os.path.normpath(os.path.join(dst_dir, it.new_name))
        if with_sidecars:
            it.sidecars = find_sidecars(it.src)
        if not out_folder and os.path.basename(it.src) == it.new_name:
            it.status = 'SUDAH SESUAI'
            continue
        it.ok = True
        it.status = 'SIAP' if kind == 'exact' else 'SIAP • NAMA MIRIP'

    # bentrok antar baris & dengan file yang sudah ada
    sources = {os.path.normcase(it.src) for it in items if it.src and it.ok}
    seen = {}
    for it in items:
        if not it.ok:
            continue
        key = os.path.normcase(it.dst)
        if key in seen:
            it.ok = False
            it.status = 'NAMA BARU BENTROK dgn baris #{}'.format(seen[key] + 1)
            bad = items[seen[key]]
            if bad.ok:
                bad.ok = False
                bad.status = 'NAMA BARU BENTROK dgn baris #{}'.format(it.row + 1)
            continue
        seen[key] = it.row
    moving = set(sources)
    for it in items:
        if it.ok:
            moving.update(os.path.normcase(p) for p, _ in it.sidecars)
    for it in items:
        if not it.ok:
            continue
        if os.path.exists(it.dst) and (out_folder or os.path.normcase(it.dst) not in sources):
            it.ok = False
            it.status = 'TUJUAN SUDAH ADA'
            continue
        for sp, rest in it.sidecars:
            sd = _sidecar_dst(it, rest)
            if os.path.exists(sd) and (out_folder or os.path.normcase(sd) not in moving):
                it.ok = False
                it.status = 'FILE PENDAMPING TUJUAN ADA'
                break
    unlisted = [p for p in images if p not in used_images]
    return items, unlisted


def _sidecar_dst(it, rest):
    src_ext = os.path.splitext(os.path.basename(it.src))[1]
    new_stem = os.path.splitext(it.new_name)[0]
    d = os.path.dirname(it.dst)
    if rest.lower().startswith(src_ext.lower() + '.'):          # Peta.jpg.aux.xml
        return os.path.join(d, it.new_name + rest[len(src_ext):])
    return os.path.join(d, new_stem + rest)                      # Peta.jgw


def execute_rename(items, mode='rename', log_folder=None, progress=None):
    """
    mode: 'rename' (ganti nama di tempat, 2 tahap agar aman dari bentrok) atau 'copy'.
    Return dict(done, errors[list], log_path)
    """
    todo = [it for it in items if it.ok]
    moves = []                       # (src, dst)
    for it in todo:
        moves.append((it.src, it.dst))
        for sp, rest in it.sidecars:
            moves.append((sp, _sidecar_dst(it, rest)))
    errors, done = [], []
    log_path = ''
    total = max(1, len(moves))

    if mode == 'copy':
        for n, (s, d) in enumerate(moves):
            try:
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copy2(s, d)
                done.append((s, d))
            except Exception as e:
                errors.append('{} -> {} : {}'.format(s, d, e))
            if progress:
                progress(int((n + 1) * 100 / total))
    else:
        staged = []                  # (tmp, dst, src)
        for n, (s, d) in enumerate(moves):
            tmp = '{}.__sls_tmp{}'.format(s, n)
            try:
                os.rename(s, tmp)
                staged.append((tmp, d, s))
            except Exception as e:
                errors.append('{} : {}'.format(s, e))
            if progress:
                progress(int((n + 1) * 50 / total))
        for n, (tmp, d, s) in enumerate(staged):
            try:
                os.makedirs(os.path.dirname(d), exist_ok=True)
                os.rename(tmp, d)
                done.append((s, d))
            except Exception as e:
                errors.append('{} -> {} : {}'.format(s, d, e))
                try:
                    os.rename(tmp, s)           # kembalikan
                except Exception:
                    pass
            if progress:
                progress(50 + int((n + 1) * 50 / max(1, len(staged))))

    if done:
        folder = log_folder or os.path.dirname(done[0][1])
        log_path = os.path.join(folder, 'SLS_RENAME_LOG_{}.json'.format(_timestamp()))
        try:
            with open(log_path, 'w', encoding='utf-8') as fh:
                json.dump({'mode': mode, 'created': datetime.now().isoformat(timespec='seconds'),
                           'moves': [{'from': s, 'to': d} for s, d in done]},
                          fh, ensure_ascii=False, indent=1)
        except Exception as e:
            errors.append('Gagal menulis log: {}'.format(e))
            log_path = ''
    return {'done': len(done), 'errors': errors, 'log_path': log_path,
            'files': len(todo)}


def undo_rename(log_path):
    """Kembalikan nama dari log mode 'rename'. Return (restored, errors)."""
    with open(log_path, 'r', encoding='utf-8') as fh:
        data = json.load(fh)
    if data.get('mode') != 'rename':
        return 0, ['Log ini dari mode SALIN; tidak ada yang perlu dikembalikan '
                   '(file asli tidak diubah).']
    moves = data.get('moves', [])
    errors, staged = [], []
    for n, m in enumerate(moves):
        tmp = '{}.__sls_undo{}'.format(m['to'], n)
        try:
            os.rename(m['to'], tmp)
            staged.append((tmp, m['from'], m['to']))
        except Exception as e:
            errors.append('{} : {}'.format(m['to'], e))
    restored = 0
    for tmp, orig, cur in staged:
        try:
            os.rename(tmp, orig)
            restored += 1
        except Exception as e:
            errors.append('{} -> {} : {}'.format(cur, orig, e))
            try:
                os.rename(tmp, cur)
            except Exception:
                pass
    return restored, errors


# ------------------------------------------------------------------
# INSERT JGW
# ------------------------------------------------------------------
JGW_MODES = ('beside', 'flat', 'subfolder')


class JgwItem(object):
    __slots__ = ('row', 'c1', 'c2', 'target', 'src', 'dst', 'status', 'ok', 'note', 'mkdir')

    def __init__(self, row, c1, c2):
        self.row = row
        self.c1 = c1
        self.c2 = c2
        self.target = ''
        self.src = ''
        self.dst = ''
        self.status = ''
        self.ok = False
        self.note = ''
        self.mkdir = False


def jgw_source_index(folder, recursive=True):
    """
    Indeks file .jgw. Nama di TXT (mis. 3210200016_WSS.jpg) cocok ke
    3210200016_WSS.jgw maupun 3210200016_WSS.jpg.jgw (dan padanan longgarnya).
    """
    return FileIndex(walk_files(folder, ('.jgw',), recursive))


def _find_jgw(index, c2, c1):
    """Cari JGW lewat nama kolom 2 dulu, lalu kolom 1. Duplikat berisi sama dianggap satu."""
    for name in (c2, c1):
        found, kind = index.find(name)
        if found:
            uniq = []
            for p in found:
                if not any(_same_content(p, q) for q in uniq):
                    uniq.append(p)
            return uniq, found
    return [], []


def _find_dir(root, wanted_keys, cache):
    """Cari sub-folder (rekursif) yang namanya cocok dgn salah satu kunci (urut prioritas)."""
    if 'dirs' not in cache:
        dirs = []
        for r, ds, _ in os.walk(root):
            ds.sort(key=str.lower)
            for d in ds:
                dirs.append(os.path.join(r, d))
        cache['dirs'] = dirs
    for key in wanted_keys:
        if not key:
            continue
        hits = [d for d in cache['dirs']
                if re.sub(r'[^a-z0-9]', '', os.path.basename(d).lower()) == key]
        if hits:
            return hits
    return []


def plan_jgw(mapping, jgw_folder, mode='beside', target_folder='', dest_folder='',
             name_mode='target', folder_key='col1', create_folders=False,
             overwrite=True, recursive=True, target_overrides=None, dest_overrides=None):
    """
    mode       : 'beside'    -> JGW ditaruh di folder raster target (cari raster dari TXT)
                 'flat'      -> semua JGW ke satu folder tujuan
                 'subfolder' -> JGW ke sub-folder (di dalam dest_folder) yang namanya sesuai TXT
    name_mode  : 'target' (nama raster target; bila tak ada pakai kolom 1) | 'col1' | 'col2' | 'asli'
    folder_key : mode subfolder, nama folder mengikuti 'col1' atau 'col2'
    Return list[JgwItem]
    """
    target_overrides = target_overrides or {}
    dest_overrides = dest_overrides or {}
    jindex = jgw_source_index(jgw_folder, recursive)
    tindex = None
    if target_folder and os.path.isdir(target_folder):
        tindex = FileIndex(walk_files(target_folder, IMAGE_EXTS, recursive))
    elif mode == 'beside':
        tindex = FileIndex([])
    dir_cache = {}
    items = []
    for i, (c1, c2) in enumerate(mapping):
        it = JgwItem(i, c1, c2)
        items.append(it)

        # --- sumber JGW
        uniq, allf = _find_jgw(jindex, c2, c1)
        if not allf:
            it.status = 'JGW TIDAK DITEMUKAN'
            continue
        if len(uniq) > 1:
            it.status = 'JGW DUPLIKAT • {}'.format(len(uniq))
            it.note = '; '.join(uniq)
            continue
        it.src = uniq[0]

        # --- raster target (wajib utk 'beside', opsional utk lainnya)
        tpath = ''
        ov = target_overrides.get(i, '')
        if ov and os.path.isfile(ov):
            tpath = ov
        elif tindex is not None:
            found, _ = tindex.find(c1)
            if not found:
                found, _ = tindex.find(c2)      # mungkin sudah di-rename ke nama kolom 2
            if len(found) > 1 and mode == 'beside':
                it.status = 'TARGET DUPLIKAT • {}'.format(len(found))
                it.note = '; '.join(found)
                continue
            if found:
                tpath = found[0]
        it.target = tpath
        if mode == 'beside' and not tpath:
            it.status = 'TARGET TIDAK ADA • KLIK 2X UNTUK PILIH'
            continue

        # --- nama file JGW
        if name_mode == 'asli':
            out_name = os.path.basename(it.src)
        else:
            if name_mode == 'col2':
                stem = split_ext(c2)[0]
            elif name_mode == 'col1':
                stem = split_ext(c1)[0]
            else:
                stem = os.path.splitext(os.path.basename(tpath))[0] if tpath else split_ext(c1)[0]
            stem = safe_filename(stem)
            if not stem:
                it.status = 'NAMA TUJUAN KOSONG'
                continue
            out_name = stem + '.jgw'

        # --- folder tujuan
        if mode == 'beside':
            dst_dir = os.path.dirname(tpath)
        elif i in dest_overrides and dest_overrides[i]:
            dst_dir = dest_overrides[i]
        elif mode == 'flat':
            if not dest_folder:
                it.status = 'FOLDER TUJUAN BELUM DIPILIH'
                continue
            dst_dir = dest_folder
        else:  # subfolder
            if not dest_folder or not os.path.isdir(dest_folder):
                it.status = 'FOLDER TUJUAN BELUM DIPILIH'
                continue
            k1 = re.sub(r'[^a-z0-9]', '', split_ext(c1)[0].lower())
            k2 = re.sub(r'[^a-z0-9]', '', split_ext(c2)[0].lower())
            keys = (k1, k2) if folder_key == 'col1' else (k2, k1)
            hits = _find_dir(dest_folder, keys, dir_cache)
            if len(hits) > 1:
                it.status = 'FOLDER DUPLIKAT • {}'.format(len(hits))
                it.note = '; '.join(hits)
                continue
            if hits:
                dst_dir = hits[0]
            elif create_folders:
                fname = safe_filename(split_ext(c1 if folder_key == 'col1' else c2)[0])
                dst_dir = os.path.join(dest_folder, fname)
                it.mkdir = True
            else:
                it.status = 'FOLDER TIDAK ADA'
                continue
        it.dst = os.path.normpath(os.path.join(dst_dir, out_name))
        it.ok = True
        if os.path.exists(it.dst):
            if _same_content(it.src, it.dst):
                it.status = 'SUDAH SAMA'
                it.ok = False
            elif overwrite:
                it.status = 'UPDATE (timpa)'
            else:
                it.status = 'ADA • TIDAK DITIMPA'
                it.ok = False
        else:
            it.status = 'BARU + BUAT FOLDER' if it.mkdir else 'BARU'

    # bentrok tujuan yang sama dari baris berbeda (isi beda)
    seen = {}
    for it in items:
        if not it.dst:
            continue
        key = os.path.normcase(it.dst)
        if key in seen:
            other = items[seen[key]]
            if other.src != it.src and not _same_content(other.src, it.src):
                it.ok = other.ok = False
                it.status = other.status = 'BENTROK • TUJUAN SAMA'
        else:
            seen[key] = it.row
    return items


def execute_jgw(items, report_folder=None, progress=None):
    """Salin JGW untuk item ok=True. Return dict(copied, updated, errors, report_path)."""
    todo = [it for it in items if it.ok]
    copied = updated = 0
    errors = []
    rows = []
    total = max(1, len(todo))
    for n, it in enumerate(todo):
        try:
            os.makedirs(os.path.dirname(it.dst), exist_ok=True)
            existed = os.path.exists(it.dst)
            shutil.copy2(it.src, it.dst)
            if existed:
                updated += 1
            else:
                copied += 1
            rows.append((it.c1, it.c2, it.src, it.dst, 'UPDATE' if existed else 'BARU'))
        except Exception as e:
            errors.append('{} -> {} : {}'.format(it.src, it.dst, e))
            rows.append((it.c1, it.c2, it.src, it.dst, 'ERROR: {}'.format(e)))
        if progress:
            progress(int((n + 1) * 100 / total))
    report_path = ''
    if rows and report_folder and os.path.isdir(report_folder):
        report_path = os.path.join(report_folder, 'SLS_JGW_REPORT_{}.csv'.format(_timestamp()))
        try:
            with open(report_path, 'w', newline='', encoding='utf-8-sig') as fh:
                w = csv.writer(fh)
                w.writerow(['TXT_KOL1', 'TXT_KOL2', 'JGW_SUMBER', 'JGW_TUJUAN', 'HASIL'])
                w.writerows(rows)
        except Exception:
            report_path = ''
    return {'copied': copied, 'updated': updated, 'errors': errors,
            'report_path': report_path, 'files': len(todo)}
