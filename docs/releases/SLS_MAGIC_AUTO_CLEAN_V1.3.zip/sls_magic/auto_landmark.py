# -*- coding: utf-8 -*-
"""AUTO TITIK BANGUNAN V1.1.25 - SLS MAGIC

Adds a non-destructive workflow for correcting existing landmark points against
black ink dots on a georeferenced scan. The source feature count is never
changed: only geometry and an existing 0/1 status attribute may be updated.
"""
from qgis.PyQt.QtWidgets import (
    QWidget, QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QPushButton,
    QLabel, QDoubleSpinBox, QSpinBox, QCheckBox, QFileDialog, QMessageBox,
    QGroupBox, QTableWidget, QTableWidgetItem, QHeaderView, QProgressBar, QLineEdit, QGridLayout,
    QTextEdit, QAbstractItemView, QApplication, QFrame, QSizePolicy, QSplitter, QTabWidget, QScrollArea
)
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QPainter, QPen, QFont
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsRasterLayer, QgsWkbTypes, QgsPointXY,
    QgsGeometry, QgsCoordinateTransform, QgsSpatialIndex, QgsFeature, QgsFeatureSink,
    QgsMarkerSymbol, QgsSymbol, QgsSingleSymbolRenderer, QgsVectorFileWriter, QgsCoordinateTransformContext, QgsField, QgsRectangle
)
import os
import math
import re
import tempfile


class CircularProgressWidget(QWidget):
    """Modern circular progress indicator with map + lightning glyphs."""
    def __init__(self, parent=None):
        super().__init__(parent); self._value=0; self.setMinimumSize(115,115); self.setMaximumHeight(180)
    def setValue(self, value):
        self._value=max(0,min(100,int(value))); self.update()
    def value(self): return self._value
    def paintEvent(self, event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        s=min(self.width(),self.height())-16; r=s/2; cx=self.width()/2; cy=self.height()/2
        pen=QPen(QColor('#dbe4ee'),9); pen.setCapStyle(Qt.RoundCap); p.setPen(pen); p.drawArc(int(cx-r),int(cy-r),int(s),int(s),0,360*16)
        pen=QPen(QColor('#1b426d'),9); pen.setCapStyle(Qt.RoundCap); p.setPen(pen); p.drawArc(int(cx-r),int(cy-r),int(s),int(s),90*16,-int(self._value*3.6*16))
        p.setPen(QColor('#183b63')); f=QFont('Segoe UI',20,QFont.Bold); p.setFont(f); p.drawText(self.rect(),Qt.AlignCenter,str(self._value)+'%')
        p.setFont(QFont('Segoe UI Emoji',14)); p.setPen(QColor('#1b426d')); p.drawText(int(cx-r+7),int(cy-r+18),22,22,Qt.AlignCenter,'🗺')
        p.setPen(QColor('#f2b233')); p.drawText(int(cx+r-28),int(cy+r-28),22,22,Qt.AlignCenter,'⚡')
        p.end()


class AutoLandmarkPage(QWidget):
    """UI + engine for AUTO TITIK BANGUNAN."""
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._last_changes = []
        self._redo_changes = []
        # AUTO TITIK BANGUNAN sengaja dikunci setiap kali modul dibuka.
        # Ini adalah UI/session lock, bukan sistem lisensi.
        self._auto_titik_locked = True
        self._auto_titik_password = "bp5"
        self._rubber_bands = []
        self._build_ui()
        self.refresh_layers()
        self._apply_auto_titik_lock_ui()

    # ------------------------------ UI ------------------------------
    def _build_ui(self):
        """Responsive workspace modeled after the plugin's other split-panel pages.
        The work area is separated from the process monitor and the tall workflow
        is divided into tabs so controls never overlap on smaller QGIS windows.
        """
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(8)

        head = QFrame()
        head.setObjectName("buildingHeader")
        hv = QHBoxLayout(head)
        hv.setContentsMargins(14, 9, 14, 9)
        hv.setSpacing(8)
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title = QLabel("AUTO TITIK BANGUNAN")
        title.setObjectName("buildingPageTitle")
        subtitle = QLabel("UPDATE LANDMARK • IDENTIFIKASI NOKTAH • SPLIT LEVEL 6")
        subtitle.setObjectName("buildingPageSubtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        hv.addLayout(title_box, 1)
        badge = QLabel("🔒 LOCKED")
        badge.setObjectName("buildingReady")
        self.auto_titik_lock_badge = badge
        badge.setAlignment(Qt.AlignCenter)
        hv.addWidget(badge)
        self.btn_auto_lock = QPushButton("🔒  LOCKED")
        self.btn_auto_lock.setObjectName("autoTitikLockButton")
        self.btn_auto_lock.setMinimumHeight(32)
        self.btn_auto_lock.setMinimumWidth(112)
        self.btn_auto_lock.clicked.connect(self._toggle_auto_titik_lock)
        hv.addWidget(self.btn_auto_lock)
        root.addWidget(head)

        # Same high-level pattern as GEOREFERENCE/AUTO CLEANING: workspace left,
        # live process monitor right, separated by a splitter.
        split = QSplitter(Qt.Horizontal)
        split.setChildrenCollapsible(False)
        split.setHandleWidth(6)

        workspace = QFrame()
        workspace.setObjectName("buildingWorkspace")
        wv = QVBoxLayout(workspace)
        wv.setContentsMargins(0, 0, 0, 0)
        wv.setSpacing(7)

        tabs = QTabWidget()
        tabs.setObjectName("buildingTabs")
        tabs.setDocumentMode(True)
        tabs.setUsesScrollButtons(True)
        self.building_tabs = tabs

        # ---- TAB 1: UPDATE TITIK ----
        update_page = QWidget()
        up = QVBoxLayout(update_page)
        up.setContentsMargins(8, 8, 8, 8)
        up.setSpacing(8)

        intro = QFrame()
        intro.setObjectName("buildingIntro")
        iv = QVBoxLayout(intro)
        iv.setContentsMargins(12, 8, 12, 8)
        intro_label = QLabel("LOAD STYLE → pilih layer titik bangunan → pilih peta scan georeference → identifikasi → generate. Feature tetap 1:1.")
        intro_label.setWordWrap(True)
        intro_label.setObjectName("sectionSubtitle")
        iv.addWidget(intro_label)
        up.addWidget(intro)

        cards = QSplitter(Qt.Horizontal)
        cards.setChildrenCollapsible(False)
        cards.setHandleWidth(6)
        cards.setOpaqueResize(True)

        src = QGroupBox("01  INPUT & STYLE")
        src.setObjectName("inputStyleCard")
        sg = QGridLayout(src)
        sg.setContentsMargins(12, 12, 12, 12)
        sg.setHorizontalSpacing(9)
        sg.setVerticalSpacing(8)
        sg.setColumnMinimumWidth(0, 125)
        sg.setColumnStretch(1, 1)
        sg.setColumnMinimumWidth(2, 98)

        def label(text):
            w = QLabel(text)
            w.setObjectName("fieldLabel")
            w.setWordWrap(True)
            return w

        self.layer_combo = QComboBox()
        self.layer_combo.setMinimumHeight(32)
        self.layer_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.layer_combo.currentIndexChanged.connect(self._layer_changed)
        sg.addWidget(label("Layer titik bangunan"), 0, 0)
        sg.addWidget(self.layer_combo, 0, 1, 1, 2)

        self.style_path = QLineEdit("Belum ada QML dipilih")
        self.style_path.setReadOnly(True)
        self.style_path.setMinimumHeight(32)
        self.style_path.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_style = QPushButton("LOAD STYLE")
        self.btn_style.setMinimumHeight(32)
        self.btn_style.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_style.clicked.connect(self.load_style)
        sg.addWidget(label("Styling titik (.QML)"), 1, 0)
        sg.addWidget(self.style_path, 1, 1)
        sg.addWidget(self.btn_style, 1, 2)

        self.raster_combo = QComboBox()
        self.raster_combo.setMinimumHeight(32)
        self.raster_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_raster = QPushButton("PILIH SCAN")
        self.btn_raster.setMinimumHeight(32)
        self.btn_raster.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_raster.clicked.connect(self.choose_raster)
        sg.addWidget(label("Peta scan georeference"), 2, 0)
        sg.addWidget(self.raster_combo, 2, 1)
        sg.addWidget(self.btn_raster, 2, 2)

        self.attr_combo = QComboBox()
        self.attr_combo.setMinimumHeight(32)
        self.attr_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sg.addWidget(label("Atribut status 1 → 0"), 3, 0)
        sg.addWidget(self.attr_combo, 3, 1, 1, 2)
        src.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        src.setMinimumWidth(320)
        cards.addWidget(src)

        rules = QGroupBox("02  RULES DETEKSI NOKTAH")
        rules.setObjectName("rulesCard")
        rg = QGridLayout(rules)
        rg.setContentsMargins(12, 12, 12, 12)
        rg.setHorizontalSpacing(9)
        rg.setVerticalSpacing(8)
        rg.setColumnMinimumWidth(0, 155)
        rg.setColumnStretch(1, 1)

        def rule(text, widget, row):
            widget.setMinimumHeight(32)
            widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            rg.addWidget(label(text), row, 0)
            rg.addWidget(widget, row, 1)

        self.radius = QDoubleSpinBox(); self.radius.setRange(.1, 1000); self.radius.setDecimals(2); self.radius.setValue(30); self.radius.setSuffix(" map unit")
        rule("Radius pencarian", self.radius, 0)
        self.dark = QSpinBox(); self.dark.setRange(1, 180); self.dark.setValue(100); self.dark.setSuffix(" /255")
        rule("Ambang tinta hitam", self.dark, 1)
        self.min_px = QSpinBox(); self.min_px.setRange(1, 10000); self.min_px.setValue(2)
        rule("Ukuran noktah minimum", self.min_px, 2)
        self.max_px = QSpinBox(); self.max_px.setRange(2, 100000); self.max_px.setValue(20000)
        rule("Ukuran noktah maksimum", self.max_px, 3)
        self.preview_only = QCheckBox("Preview dahulu — jangan ubah layer")
        rg.addWidget(self.preview_only, 4, 0, 1, 2)
        rules.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rules.setMinimumWidth(320)
        cards.addWidget(rules)
        cards.setStretchFactor(0, 1)
        cards.setStretchFactor(1, 1)
        cards.setSizes([460, 460])
        up.addWidget(cards, 0)

        action = QFrame()
        action.setObjectName("buildingActionBar")
        av = QHBoxLayout(action)
        av.setContentsMargins(7, 6, 7, 6)
        av.setSpacing(7)
        self.btn_refresh = QPushButton("↻  REFRESH")
        self.btn_identify = QPushButton("IDENTIFIKASI NOKTAH")
        self.btn_generate = QPushButton("⚡  GENERATE & UPDATE")
        self.btn_clear_highlight = QPushButton("CLEAR HIGHLIGHT")
        self.btn_undo_generate = QPushButton("↶ UNDO")
        self.btn_redo_generate = QPushButton("↷ REDO")
        self.btn_refresh.clicked.connect(self.refresh_layers)
        self.btn_identify.clicked.connect(self.identify)
        self.btn_generate.clicked.connect(self.generate)
        self.btn_clear_highlight.clicked.connect(self.clear_highlight)
        self.btn_undo_generate.clicked.connect(self.undo_generate)
        self.btn_redo_generate.clicked.connect(self.redo_generate)
        self.btn_refresh.setMinimumHeight(36)
        self.btn_identify.setMinimumHeight(36)
        self.btn_generate.setMinimumHeight(36)
        self.btn_clear_highlight.setMinimumHeight(36)
        self.btn_undo_generate.setMinimumHeight(36)
        self.btn_redo_generate.setMinimumHeight(36)
        self.btn_refresh.setFixedWidth(112)
        self.btn_identify.setFixedWidth(178)
        self.btn_clear_highlight.setFixedWidth(118)
        self.btn_undo_generate.setFixedWidth(82)
        self.btn_redo_generate.setFixedWidth(82)
        av.addWidget(self.btn_refresh)
        av.addWidget(self.btn_identify)
        av.addWidget(self.btn_clear_highlight)
        av.addWidget(self.btn_undo_generate)
        av.addWidget(self.btn_redo_generate)
        av.addWidget(self.btn_generate, 1)
        up.addWidget(action)
        up.addStretch(1)
        tabs.addTab(update_page, "UPDATE TITIK")

        # ---- TAB 2: SPLIT TITIK BANGUNAN PER IDsLS ----
        split_page = QWidget()
        sp = QVBoxLayout(split_page)
        sp.setContentsMargins(8, 8, 8, 8)
        sp.setSpacing(8)
        split_group = QGroupBox("03  SPLIT TITIK BANGUNAN PER IDsLS  |  OTOMATIS KE GROUP DESA")
        split_group.setObjectName("splitCard")
        sg2 = QGridLayout(split_group)
        sg2.setContentsMargins(14, 14, 14, 14)
        sg2.setHorizontalSpacing(10)
        sg2.setVerticalSpacing(9)
        sg2.setColumnMinimumWidth(0, 155)
        sg2.setColumnStretch(1, 1)

        self.split_selected_layer = QLabel("Belum ada layer titik bangunan dipilih")
        self.split_selected_layer.setObjectName("splitSelectedLayer")
        self.split_selected_layer.setWordWrap(True)
        sg2.addWidget(label("Layer input"), 0, 0)
        sg2.addWidget(self.split_selected_layer, 0, 1, 1, 2)

        self.split_field_combo = QComboBox()
        self.split_field_combo.setMinimumHeight(34)
        self.split_field_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.split_field_combo.setToolTip("Field pemisah titik. Gunakan IDsLS / ID SLS.")
        self.btn_split_refresh = QPushButton("↻")
        self.btn_split_refresh.setFixedSize(34, 34)
        self.btn_split_refresh.clicked.connect(self._refresh_split_fields)
        fr = QHBoxLayout(); fr.setContentsMargins(0,0,0,0); fr.setSpacing(5)
        fr.addWidget(self.split_field_combo,1); fr.addWidget(self.btn_split_refresh)
        sg2.addWidget(label("IDsLS field"), 1, 0)
        sg2.addLayout(fr, 1, 1, 1, 2)

        self.split_summary = QLabel(
            "Alur: pilih Layer Titik Bangunan di INPUT & STYLE → pilih field IDsLS → klik SPLIT. "
            "Semua hasil dibuat sebagai memory layer di dalam satu folder QGIS bernama SPLIT, "
            "kemudian dikelompokkan per desa."
        )
        self.split_summary.setWordWrap(True); self.split_summary.setObjectName("splitSummary")
        sg2.addWidget(self.split_summary, 2, 0, 1, 3)

        self.btn_split = QPushButton("✂  SPLIT TITIK → FOLDER SPLIT")
        self.btn_split.setMinimumHeight(42)
        self.btn_split.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_split.clicked.connect(self.split_per_sls)
        sg2.addWidget(self.btn_split, 3, 0, 1, 3)

        # ---- REPORT SPLIT ----
        report_box = QGroupBox("LAPORAN HASIL SPLIT — SELURUH DESA")
        report_box.setObjectName("splitReportCard")
        rv = QVBoxLayout(report_box)
        rv.setContentsMargins(10, 10, 10, 10)
        rv.setSpacing(6)
        self.split_report = QTableWidget(0, 4)
        self.split_report.setHorizontalHeaderLabels(["NAMA DESA / GROUP", "JUMLAH IDsLS", "TOTAL TITIK", "STATUS"])
        self.split_report.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.split_report.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.split_report.setAlternatingRowColors(True)
        self.split_report.verticalHeader().setVisible(False)
        self.split_report.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.split_report.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.split_report.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.split_report.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.split_report.setMinimumHeight(150)
        rv.addWidget(self.split_report)
        self.split_report_total = QLabel("Belum ada hasil split.")
        self.split_report_total.setObjectName("splitReportTotal")
        rv.addWidget(self.split_report_total)

        self.btn_merge = QPushButton("⛓  MERGE TITIK PER DESA → GROUP DESA")
        self.btn_merge.setMinimumHeight(42)
        self.btn_merge.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_merge.clicked.connect(self.merge_split_per_desa)
        rv.addWidget(self.btn_merge)

        self.merge_report = QLabel("Merge belum dijalankan. Semua layer hasil split dapat digabung kembali per desa tanpa membuat file output.")
        self.merge_report.setWordWrap(True)
        self.merge_report.setObjectName("mergeReport")
        rv.addWidget(self.merge_report)

        sp.addWidget(split_group)
        sp.addWidget(report_box, 1)
        tabs.addTab(split_page, "SPLIT IDsLS")

        # ---- TAB 3: RESULTS ----
        result_page = QWidget()
        rp = QVBoxLayout(result_page); rp.setContentsMargins(8,8,8,8); rp.setSpacing(7)
        result = QGroupBox("04  HASIL IDENTIFIKASI / PERUBAHAN")
        rv = QVBoxLayout(result); rv.setContentsMargins(10,8,10,8); rv.setSpacing(5)
        self.summary = QLabel("Belum ada proses."); rv.addWidget(self.summary)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["FID", "Status", "Jarak", "DX", "DY", "Hasil"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        rv.addWidget(self.table, 1)
        rp.addWidget(result, 1)
        tabs.addTab(result_page, "HASIL")

        # Scroll wrapper keeps the whole left workflow usable on short screens.
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(tabs)
        wv.addWidget(scroll, 1)
        split.addWidget(workspace)

        # ---- RIGHT PROCESS MONITOR ----
        right = QFrame(); right.setObjectName("buildingSidePanel")
        right.setMinimumWidth(300); right.setMaximumWidth(360)
        rv2 = QVBoxLayout(right); rv2.setContentsMargins(12,12,12,12); rv2.setSpacing(9)
        status_card = QGroupBox("PROCESS MONITOR")
        sv = QVBoxLayout(status_card); sv.setContentsMargins(8,8,8,8); sv.setSpacing(6)
        self.progress_side = CircularProgressWidget(); self.progress_side.setMinimumSize(150,150); self.progress_side.setMaximumHeight(170)
        sv.addWidget(self.progress_side,0,Qt.AlignCenter)
        self.side_status = QLabel("READY\nMenunggu proses"); self.side_status.setAlignment(Qt.AlignCenter); self.side_status.setObjectName("sideStatus"); sv.addWidget(self.side_status)
        rv2.addWidget(status_card,0)
        log_card = QGroupBox("PROCESS LOG")
        lv = QVBoxLayout(log_card); lv.setContentsMargins(8,8,8,8)
        self.log = QTextEdit(); self.log.setReadOnly(True); self.log.setPlaceholderText("Log proses akan tampil di sini..."); lv.addWidget(self.log,1); rv2.addWidget(log_card,1)
        split.addWidget(right)
        split.setSizes([850,320]); split.setStretchFactor(0,1); split.setStretchFactor(1,0)
        root.addWidget(split,1)

        self.setStyleSheet("""
            QFrame#buildingHeader, QFrame#buildingWorkspace, QFrame#buildingActionBar { background:#ffffff; border:1px solid #dfe5ec; border-radius:9px; }
            QFrame#buildingIntro { background:#f8fafc; border:1px solid #e2e8ef; border-radius:8px; }
            QLabel#buildingPageTitle { color:#17365D; font-size:12pt; font-weight:800; }
            QLabel#buildingPageSubtitle { color:#7b8795; font-size:8pt; }
            QLabel#buildingReady { color:#16834a; background:#e8f7ef; border:1px solid #bfe8d0; border-radius:12px; padding:5px 12px; font-weight:800; }
            QGroupBox#inputStyleCard, QGroupBox#rulesCard, QGroupBox#splitCard { border:1px solid #d6e0ea; border-radius:9px; margin-top:10px; background:#ffffff; }
            QGroupBox#inputStyleCard::title, QGroupBox#rulesCard::title, QGroupBox#splitCard::title { subcontrol-origin:margin; left:12px; padding:0 7px; font-weight:800; }
            QGroupBox#rulesCard, QGroupBox#splitCard { border:2px solid #52b788; background:#fbfffc; }
            QLabel#splitSelectedLayer { color:#176b42; font-weight:800; padding:6px 8px; background:#eefaf3; border:1px solid #bfe7cf; border-radius:6px; }
            QGroupBox#rulesCard::title, QGroupBox#splitCard::title { color:#16834a; }
            QGroupBox#splitCard QPushButton { border:1px solid #42a76f; background:#e8f7ef; color:#176b42; border-radius:7px; font-weight:800; padding:6px 12px; }
            QGroupBox#splitCard QPushButton:hover { background:#d9f2e4; }
            QTabWidget#buildingTabs::pane { border:1px solid #dfe5ec; border-radius:8px; background:#ffffff; }
            QTabWidget#buildingTabs QTabBar::tab { background:#f5f7fa; color:#526173; padding:7px 18px; margin-right:3px; border:1px solid #dfe5ec; border-bottom:none; border-top-left-radius:7px; border-top-right-radius:7px; font-size:8pt; font-weight:700; }
            QTabWidget#buildingTabs QTabBar::tab:selected { background:#17365D; color:#ffffff; border-color:#17365D; }
            QTabWidget#buildingTabs QTabBar::tab:hover { background:#eef5fb; color:#17365D; }
            QFrame#buildingSidePanel { background:#f8fafc; border:1px solid #dfe5ec; border-radius:9px; }
            QGroupBox#buildingSidePanel { border:1px solid #dfe5ec; }
            QGroupBox#buildingSidePanel, QGroupBox#buildingSidePanel::title { font-weight:800; }
            QScrollArea { background:transparent; }
            QScrollBar:vertical { width:10px; background:transparent; margin:2px; }
            QScrollBar::handle:vertical { background:#cbd4de; border-radius:5px; min-height:25px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
        """)

    def _set_progress(self, value):

        if hasattr(self, "progress_side"): self.progress_side.setValue(value)
        if hasattr(self, "side_status"):
            self.side_status.setText(("READY\nMenunggu proses" if int(value)==0 else ("SELESAI\n100%" if int(value)>=100 else "PROCESSING\n{}%".format(int(value)))))
        QApplication.processEvents()

    # ------------------------------ data ------------------------------
    def refresh_layers(self):
        current = self.layer_combo.currentData() if self.layer_combo.count() else None
        self.layer_combo.blockSignals(True)
        self.layer_combo.clear()
        self.raster_combo.clear()
        layers = QgsProject.instance().mapLayers().values()
        points = []
        rasters = []
        for layer in layers:
            if isinstance(layer, QgsVectorLayer) and layer.isValid() and layer.geometryType() == QgsWkbTypes.PointGeometry:
                points.append(layer)
            elif isinstance(layer, QgsRasterLayer) and layer.isValid():
                rasters.append(layer)
        points.sort(key=lambda x: x.name().lower())
        rasters.sort(key=lambda x: x.name().lower())
        for layer in points:
            self.layer_combo.addItem(layer.name(), layer.id())
        for layer in rasters:
            self.raster_combo.addItem(layer.name(), layer.id())
        if current:
            idx = self.layer_combo.findData(current)
            if idx >= 0: self.layer_combo.setCurrentIndex(idx)
        self.layer_combo.blockSignals(False)
        self._layer_changed()
        self._refresh_split_fields()
        self._update_split_selected_layer()

    def _selected_layer(self):
        lid = self.layer_combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    def _selected_raster(self):
        lid = self.raster_combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    def _update_split_selected_layer(self):
        """Keep Split explicitly tied to the layer selected in INPUT & STYLE."""
        layer = self._selected_layer()
        if layer and layer.isValid():
            self.split_selected_layer.setText(
                "✓  {}  •  {} feature".format(layer.name(), layer.featureCount())
            )
        else:
            self.split_selected_layer.setText("⚠  Pilih layer titik bangunan terlebih dahulu")

    def _layer_changed(self):
        self.attr_combo.clear()
        layer = self._selected_layer()
        self._update_split_selected_layer()
        if not layer: return
        fields = layer.fields()
        scored = []
        for f in fields:
            vals = []
            try:
                for ft in layer.getFeatures():
                    v = ft[f.name()]
                    if v is not None and str(v).strip() != "": vals.append(str(v).strip())
                    if len(vals) >= 1000: break
            except Exception: vals = []
            score = 0
            lname = f.name().lower()
            if any(k in lname for k in ("status", "kode", "code", "ident", "hasil", "cek", "sl_s", "sls")): score += 5
            if vals and all(v in ("0", "1", "0.0", "1.0") for v in vals): score += 10
            if f.type() in (QVariant.Int, QVariant.UInt, QVariant.LongLong, QVariant.ULongLong, QVariant.Double): score += 2
            scored.append((score, f.name()))
        for _, name in sorted(scored, reverse=True): self.attr_combo.addItem(name)
        if self.attr_combo.count() == 0: self.attr_combo.addItem("(tidak ada atribut 0/1)")

    def _refresh_split_fields(self):
        self.split_field_combo.clear()
        layer=self._selected_layer()
        if not layer: return
        names=[f.name() for f in layer.fields()]
        preferred=[n for n in names if n.lower().replace(" ", "_") in (
            "idsls", "id_sls", "id_sls_", "idsls_", "sls", "level_6_full_code"
        )]
        ordered=preferred+[n for n in names if n not in preferred]
        self.split_field_combo.addItems(ordered)
        for i,n in enumerate(ordered):
            if n.lower().replace(" ", "_") in ("idsls", "id_sls", "idsls_", "id_sls_"):
                self.split_field_combo.setCurrentIndex(i); break
        else:
            for i,n in enumerate(ordered):
                if n.lower()=="level_6_full_code":
                    self.split_field_combo.setCurrentIndex(i); break

    def _choose_split_output(self):
        default=os.path.join(os.path.expanduser("~"),"TITIK_BANGUNAN_PER_SLS_LEVEL6.gpkg")
        path,_=QFileDialog.getSaveFileName(self,"Simpan GeoPackage Split SLS",default,"GeoPackage (*.gpkg)")
        if path:
            if not path.lower().endswith(".gpkg"): path += ".gpkg"
            self.split_output.setText(path)

    @staticmethod
    def _safe_layer_name(value, used=None):
        import re
        txt=str(value).strip()
        txt=re.sub(r"[^0-9A-Za-z_]+","_",txt) or "UNKNOWN"
        name="SLS_"+txt
        if len(name)>60: name=name[:60]
        if used is not None:
            base=name; i=2
            while name.lower() in used:
                suffix="_{}".format(i); name=(base[:60-len(suffix)]+suffix); i+=1
            used.add(name.lower())
        return name

    @staticmethod
    def _desa_group_key(level6_value):
        """Derive the desa code from a Level-6 SLS code.

        For Indonesian SLS codes used by this workflow, the first 10 digits
        identify the desa (province + kabupaten/kota + kecamatan + desa).
        If a value is not numeric/long enough, keep a safe textual group key.
        """
        raw=str(level6_value).strip()
        digits=''.join(re.findall(r"\d", raw))
        if len(digits) >= 10:
            return digits[:10]
        return raw or "UNKNOWN"

    @staticmethod
    def _ensure_group(root, group_name):
        """Find/create a top-level QGIS layer-tree group without duplicates."""
        group=root.findGroup(group_name)
        if group is None:
            group=root.addGroup(group_name)
        return group

    def _remove_output_layers_from_project(self, out_path):
        """Release QGIS/OGR handles to a previous output GeoPackage."""
        target=os.path.normcase(os.path.normpath(out_path))
        project=QgsProject.instance()
        for lyr in list(project.mapLayers().values()):
            try:
                src=lyr.source()
                # OGR sources may include |layername=...
                src_base=os.path.normcase(os.path.normpath(src.split("|",1)[0]))
                if src_base == target:
                    project.removeMapLayer(lyr.id())
            except Exception:
                pass
        QApplication.processEvents()
        try:
            import gc; gc.collect()
        except Exception:
            pass

    def _prepare_split_output(self, out_path):
        """Prepare a GeoPackage path, including safe release of old QGIS layers."""
        if not os.path.exists(out_path):
            return
        self._remove_output_layers_from_project(out_path)
        try:
            os.remove(out_path)
            return
        except Exception as first:
            # A second attempt after provider cleanup is useful on Windows.
            QApplication.processEvents()
            try:
                import gc; gc.collect()
                os.remove(out_path)
                return
            except Exception as second:
                raise RuntimeError(
                    "GeoPackage output masih dikunci oleh QGIS/proses lain. "
                    "Layer hasil dari file tersebut sudah dilepas dari project, "
                    "tetapi Windows masih menahan file. Tutup file/layer tersebut "
                    "atau pilih nama GeoPackage baru lalu ulangi.\n\n{}".format(second)
                )

    def _add_split_layer_to_project(self, out, layer_name, desa_name, source_layer):
        """Add one GPKG layer into the requested desa group."""
        if not self.split_add_project.isChecked():
            return False
        uri="{}|layername={}".format(out, layer_name)
        vl=QgsVectorLayer(uri, layer_name, "ogr")
        if not vl.isValid():
            self.log.append("  REVIEW: layer output tidak valid → {}".format(layer_name))
            return False
        if self.split_split_style.isChecked():
            try:
                vl.setRenderer(source_layer.renderer().clone())
                vl.triggerRepaint()
            except Exception:
                pass
        project=QgsProject.instance()
        project.addMapLayer(vl, False)
        group=self._ensure_group(project.layerTreeRoot(), desa_name)
        # Add exactly once to the requested desa group.
        if not any(hasattr(child, 'layerId') and child.layerId()==vl.id() for child in group.children()):
            group.addLayer(vl)
        return True

    def _desa_report_name(self, idsls, features):
        """Return a useful desa label: actual desa name when a common name field exists, otherwise code."""
        code = self._desa_group_key(idsls)
        candidates = {"desa", "nama_desa", "namadesa", "nm_desa", "village", "villagename", "desa_name", "namawilayah"}
        try:
            layer = self._selected_layer()
            if layer:
                field_name = None
                for f in layer.fields():
                    n = re.sub(r"[^a-z0-9]+", "_", f.name().lower()).strip("_")
                    if n in candidates:
                        field_name = f.name(); break
                if field_name:
                    vals = []
                    for ft in features:
                        v = ft[field_name]
                        if v is not None and str(v).strip():
                            vals.append(str(v).strip())
                    if vals:
                        return "{} — {}".format(code, vals[0])
        except Exception:
            pass
        return "DESA_{}".format(code)

    def _fill_split_report(self, desa_stats):
        self.split_report.setRowCount(0)
        total_points = 0
        total_idsls = 0
        for desa_name, stat in sorted(desa_stats.items(), key=lambda x: x[0]):
            row = self.split_report.rowCount()
            self.split_report.insertRow(row)
            self.split_report.setItem(row, 0, QTableWidgetItem(str(stat.get("display", desa_name))))
            self.split_report.setItem(row, 1, QTableWidgetItem(str(stat.get("idsls", 0))))
            self.split_report.setItem(row, 2, QTableWidgetItem(str(stat.get("points", 0))))
            self.split_report.setItem(row, 3, QTableWidgetItem("OK" if stat.get("points", 0) == stat.get("source_points", stat.get("points", 0)) else "REVIEW"))
            total_points += int(stat.get("points", 0))
            total_idsls += int(stat.get("idsls", 0))
        self.split_report_total.setText(
            "TOTAL GABUNGAN SELURUH DESA  •  {} DESA  •  {} IDsLS  •  {} TITIK".format(
                len(desa_stats), total_idsls, total_points
            )
        )

    def merge_split_per_desa(self):
        """Merge generated IDsLS memory layers back to one layer per desa,
        keeping everything inside the single SPLIT folder."""
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        split_root = root.findGroup("SPLIT")
        desa_groups = []
        if split_root is not None:
            for child in split_root.children():
                try:
                    if child.nodeType() == 0 and child.customProperty("sls_magic_split_group", False):
                        desa_groups.append(child)
                except Exception:
                    pass

        if not desa_groups:
            QMessageBox.warning(
                self, "Merge Titik",
                "Belum ada group desa di dalam folder SPLIT. Jalankan SPLIT terlebih dahulu."
            )
            return

        merged_total = 0
        merged_groups = 0
        self.log.append("MERGE DESA: menggabungkan layer IDsLS di dalam folder SPLIT...")
        merge_details = []

        try:
            for group in sorted(desa_groups, key=lambda g: g.name().lower()):
                source_layers = []
                for child in group.children():
                    try:
                        lyr = child.layer() if child.nodeType() == 1 else None
                        if (lyr and lyr.isValid()
                                and lyr.customProperty("sls_magic_split_idsls", False)
                                and not lyr.customProperty("sls_magic_merged_desa", False)):
                            source_layers.append(lyr)
                    except Exception:
                        pass

                if not source_layers:
                    continue

                # Remove an earlier merge result in the same desa group.
                for child in list(group.children()):
                    try:
                        old = child.layer() if child.nodeType() == 1 else None
                        if old and old.customProperty("sls_magic_merged_desa", False):
                            project.removeMapLayer(old.id())
                    except Exception:
                        pass
                QApplication.processEvents()

                base = source_layers[0]
                safe_group = re.sub(r"[^0-9A-Za-z_]+", "_", group.name()).strip("_")
                merge_name = ("TITIK_MERGE_" + safe_group)[:60]
                mem = QgsVectorLayer(
                    "{}?crs={}".format(
                        QgsWkbTypes.displayString(base.wkbType()),
                        base.crs().authid() or base.crs().toWkt()
                    ),
                    merge_name,
                    "memory"
                )
                if not mem.isValid():
                    self.log.append("  ✗ {} : gagal membuat layer merge".format(group.name()))
                    continue

                dp = mem.dataProvider()
                if not dp.addAttributes(list(base.fields())):
                    self.log.append("  ✗ {} : gagal menyalin schema merge".format(group.name()))
                    continue
                mem.updateFields()

                out_features = []
                for src_layer in source_layers:
                    for ft in src_layer.getFeatures():
                        geom = ft.geometry()
                        if geom is None or geom.isNull() or geom.isEmpty():
                            continue
                        nf = QgsFeature(mem.fields())
                        nf.setAttributes(list(ft.attributes()))
                        nf.setGeometry(QgsGeometry(geom))
                        out_features.append(nf)

                ok, added = dp.addFeatures(out_features)
                mem.updateExtents()
                if not ok or len(added) != len(out_features):
                    self.log.append(
                        "  ✗ {} : merge hanya {}/{} feature".format(
                            group.name(), len(added), len(out_features)
                        )
                    )
                    continue

                mem.setCustomProperty("sls_magic_merged_desa", True)
                mem.setCustomProperty("sls_magic_merge_group", group.name())
                mem.setCustomProperty("sls_magic_merge_source_count", len(source_layers))
                try:
                    mem.setRenderer(base.renderer().clone())
                    mem.setOpacity(base.opacity())
                except Exception:
                    pass

                project.addMapLayer(mem, False)
                group.addLayer(mem)
                merged_groups += 1
                merged_total += len(added)
                merge_details.append(
                    "{}: {} layer → {} titik".format(
                        group.name(), len(source_layers), len(added)
                    )
                )
                self.log.append(
                    "  ✓ {} → {} layer digabung, {} titik".format(
                        group.name(), len(source_layers), len(added)
                    )
                )
                QApplication.processEvents()

            self.merge_report.setText(
                "MERGE SELESAI  •  {} DESA  •  {} TITIK GABUNGAN\n{}".format(
                    merged_groups, merged_total,
                    "\n".join(merge_details) if merge_details
                    else "Tidak ada layer yang dapat digabung."
                )
            )
            self._set_progress(100)
            QMessageBox.information(
                self, "Merge Titik selesai",
                "{} desa berhasil di-merge.\n\nTotal titik gabungan: {}\n\n"
                "Hasil tetap berada di folder SPLIT, pada masing-masing desa.".format(
                    merged_groups, merged_total
                )
            )
        except Exception as e:
            self.log.append("MERGE DESA ERROR: {}".format(e))
            QMessageBox.critical(self, "Merge Titik gagal", str(e))


    def split_per_sls(self):
        """Split selected building points by IDsLS into one QGIS group named SPLIT.

        Workflow:
          1) select the input layer in the main Layer Titik Bangunan combo;
          2) click SPLIT;
          3) IDsLS values become memory layers;
          4) all layers live under one top-level SPLIT group;
          5) IDsLS layers are nested by desa (first 10 digits of IDsLS).
        The source layer is never modified and no output file is created.
        """
        layer = self._selected_layer()
        if not layer or not layer.isValid():
            QMessageBox.warning(self, "Split Titik Bangunan",
                                "Pilih layer titik bangunan terlebih dahulu pada bagian INPUT & STYLE.")
            return

        if layer.geometryType() != QgsWkbTypes.PointGeometry:
            QMessageBox.warning(self, "Split Titik Bangunan",
                                "Layer terpilih bukan layer titik.")
            return

        # IDsLS must be selected/available. Prefer the real IDsLS field.
        field = self.split_field_combo.currentText().strip()
        idsls_candidates = []
        for f in layer.fields():
            norm = re.sub(r"[^a-z0-9]+", "_", f.name().lower()).strip("_")
            if norm in ("idsls", "id_sls", "level_6_full_code"):
                idsls_candidates.append(f.name())
        if idsls_candidates:
            field = idsls_candidates[0]
            self.split_field_combo.setCurrentText(field)

        if not field or layer.fields().indexOf(field) < 0:
            QMessageBox.warning(self, "Split Titik Bangunan",
                                "Field IDsLS tidak ditemukan pada layer terpilih.")
            return

        try:
            project = QgsProject.instance()
            root = project.layerTreeRoot()

            # Read source once. Nothing is edited in the source layer.
            groups = {}
            source_count = 0
            empty_count = 0
            for ft in layer.getFeatures():
                source_count += 1
                raw = ft[field]
                if raw is None or str(raw).strip() == "":
                    empty_count += 1
                    continue
                idsls = str(raw).strip()
                groups.setdefault(idsls, []).append(ft)

            if not groups:
                QMessageBox.warning(self, "Split Titik Bangunan",
                                    "Tidak ada nilai IDsLS yang dapat diproses.")
                return

            # Remove ONLY the previous generated SPLIT group and its generated
            # memory layers. User-created groups outside SPLIT remain untouched.
            old_split = root.findGroup("SPLIT")
            if old_split is not None:
                generated_ids = []
                def collect_ids(node):
                    for child in list(node.children()):
                        if child.nodeType() == 1:
                            collect_ids(child)
                        elif child.nodeType() == 0:
                            lyr = child.layer()
                            if lyr:
                                generated_ids.append(lyr.id())
                collect_ids(old_split)
                for lid in generated_ids:
                    try:
                        project.removeMapLayer(lid)
                    except Exception:
                        pass
                try:
                    root.removeChildNode(old_split)
                except Exception:
                    pass
                QApplication.processEvents()

            split_root = root.addGroup("SPLIT")
            split_root.setCustomProperty("sls_magic_split_root", True)

            flat_wkb = QgsWkbTypes.flatType(layer.wkbType())
            wkb_name = QgsWkbTypes.displayString(flat_wkb) or "Point"
            crs_id = layer.crs().authid() or layer.crs().toWkt()
            used_names = set()
            total_written = 0
            layer_count = 0
            desa_stats = {}
            combined_extent = None

            self.log.append(
                "SPLIT: layer '{}' | {} feature | field '{}' | {} IDsLS".format(
                    layer.name(), source_count, field, len(groups)
                )
            )
            self.log.append("OUTPUT: satu folder QGIS → SPLIT → DESA → layer IDsLS")

            for idx, (idsls, feats) in enumerate(sorted(groups.items(), key=lambda x: x[0]), 1):
                safe_idsls = re.sub(r"[^0-9A-Za-z_]+", "_", idsls) or "UNKNOWN"
                layer_name = "TITIK_" + safe_idsls
                if len(layer_name) > 60:
                    layer_name = layer_name[:60]
                base = layer_name
                n = 2
                while layer_name.lower() in used_names:
                    suffix = "_{}".format(n)
                    layer_name = base[:60-len(suffix)] + suffix
                    n += 1
                used_names.add(layer_name.lower())

                mem = QgsVectorLayer("{}?crs={}".format(wkb_name, crs_id),
                                     layer_name, "memory")
                if not mem.isValid():
                    self.log.append("✗ {} : gagal membuat memory layer {}".format(idsls, wkb_name))
                    continue

                dp = mem.dataProvider()
                if not dp.addAttributes(list(layer.fields())):
                    self.log.append("✗ {} : gagal menyalin schema atribut".format(idsls))
                    continue
                mem.updateFields()

                new_features = []
                for src in feats:
                    geom = src.geometry()
                    if geom is None or geom.isNull() or geom.isEmpty():
                        continue
                    # Create a fresh feature against the destination schema. This is
                    # safer than cloning the source feature because memory layers can
                    # otherwise retain a source-layer field/geometry binding.
                    nf = QgsFeature(mem.fields())
                    nf.setAttributes(list(src.attributes()))
                    nf.setGeometry(QgsGeometry(geom))
                    new_features.append(nf)

                ok, added = dp.addFeatures(new_features)
                if not ok or len(added) != len(new_features):
                    self.log.append(
                        "✗ {} : hanya {}/{} feature berhasil ditambahkan".format(
                            idsls, len(added), len(new_features)
                        )
                    )
                    continue
                mem.updateExtents()
                # Diagnostic: a successful split must have both features and a
                # non-empty extent before the layer is inserted into the tree.
                if mem.featureCount() != len(new_features):
                    self.log.append("✗ {} : featureCount {} != expected {}".format(idsls, mem.featureCount(), len(new_features)))
                    continue

                # Keep the output visibly rendered. A copied renderer can contain
                # category/rule filters that hide all features after splitting, so
                # use a simple default point renderer when possible.
                try:
                    mem.setRenderer(QgsSingleSymbolRenderer(QgsSymbol.defaultSymbol(mem.geometryType())))
                except Exception:
                    try:
                        mem.setRenderer(layer.renderer().clone())
                    except Exception:
                        pass
                try:
                    mem.setOpacity(layer.opacity())
                except Exception:
                    pass

                mem.setCustomProperty("sls_magic_split_idsls", True)
                mem.setCustomProperty("sls_magic_source_layer", layer.id())
                mem.setCustomProperty("sls_magic_idsls", idsls)

                # One desa subgroup inside the single SPLIT folder.
                desa_key = self._desa_group_key(idsls)
                desa_name = self._desa_report_name(idsls, feats)
                safe_desa = re.sub(r"[^0-9A-Za-z_\- ]+", "_", str(desa_name)).strip() or ("DESA_" + desa_key)

                group = None
                for child in split_root.children():
                    if child.nodeType() == 0 and child.customProperty("sls_magic_split_group", False):
                        if child.customProperty("sls_magic_desa_key", "") == desa_key:
                            group = child
                            break
                if group is None:
                    group = split_root.addGroup(safe_desa)
                    group.setCustomProperty("sls_magic_split_group", True)
                    group.setCustomProperty("sls_magic_desa_key", desa_key)

                # Register the memory layer first, then explicitly create its tree
                # node under SPLIT and force it visible. Do not rely on the default
                # checked state of addMapLayer(False), which can differ between QGIS
                # versions.
                project.addMapLayer(mem, False)
                node = group.addLayer(mem)
                if node is not None:
                    node.setItemVisibilityChecked(True)
                mem.setReadOnly(False)
                mem.updateExtents()
                mem.triggerRepaint()

                total_written += len(new_features)
                layer_count += 1
                try:
                    if combined_extent is None:
                        combined_extent = QgsRectangle(mem.extent())
                    else:
                        combined_extent.combineExtentWith(mem.extent())
                except Exception:
                    pass
                if desa_key not in desa_stats:
                    desa_stats[desa_key] = {
                        "idsls": 0,
                        "points": 0,
                        "display": desa_name,
                        "source_points": 0,
                    }
                desa_stats[desa_key]["idsls"] += 1
                desa_stats[desa_key]["points"] += len(new_features)
                desa_stats[desa_key]["source_points"] += len(new_features)

                self.log.append(
                    "  ✓ {} → {} : {} titik".format(idsls, desa_name, len(new_features))
                )
                self._set_progress(int(idx * 100 / max(1, len(groups))))
                QApplication.processEvents()

            # Move the map canvas to the actual extent of the generated points.
            # This makes the new split layers immediately visible even when the
            # previous canvas was centered on a raster or polygon elsewhere.
            if combined_extent is not None and not combined_extent.isEmpty():
                try:
                    canvas = self.iface.mapCanvas()
                    ext = QgsRectangle(combined_extent)
                    pad_x = max(ext.width() * 0.10, 1e-9)
                    pad_y = max(ext.height() * 0.10, 1e-9)
                    ext.setXMinimum(ext.xMinimum() - pad_x)
                    ext.setXMaximum(ext.xMaximum() + pad_x)
                    ext.setYMinimum(ext.yMinimum() - pad_y)
                    ext.setYMaximum(ext.yMaximum() + pad_y)
                    canvas.setExtent(ext)
                    canvas.refresh()
                    self.log.append("CANVAS ZOOM: X {:.3f}..{:.3f} | Y {:.3f}..{:.3f}".format(
                        ext.xMinimum(), ext.xMaximum(), ext.yMinimum(), ext.yMaximum()))
                except Exception as zoom_err:
                    self.log.append("CANVAS ZOOM WARNING: {}".format(zoom_err))

            self._fill_split_report(desa_stats)
            self.split_summary.setText(
                "INPUT: {}  |  IDsLS: {}  |  DESA: {}  |  LAYER: {}  |  "
                "SUMBER: {} titik  |  HASIL: {} titik  |  TANPA IDsLS: {}".format(
                    layer.name(), len(groups), len(desa_stats), layer_count,
                    source_count, total_written, empty_count
                )
            )
            self.log.append(
                "SPLIT selesai: {} desa | {} layer IDsLS | {} titik".format(
                    len(desa_stats), layer_count, total_written
                )
            )

            # Guarantee that the output is not silently incomplete.
            if total_written != source_count - empty_count:
                QMessageBox.warning(
                    self, "Split selesai dengan peringatan",
                    "Sebagian feature tidak masuk hasil split.\n\n"
                    "Sumber: {}\nTanpa IDsLS: {}\nHasil: {}\n\n"
                    "Folder SPLIT tetap dibuat; periksa log untuk detail.".format(
                        source_count, empty_count, total_written
                    )
                )
            elif empty_count:
                QMessageBox.information(
                    self, "Split selesai",
                    "{} titik berhasil dimasukkan ke folder SPLIT.\n\n"
                    "Desa: {}\nLayer IDsLS: {}\nTanpa IDsLS: {}\n\n"
                    "Feature tanpa IDsLS memang tidak dapat dipisahkan.".format(
                        total_written, len(desa_stats), layer_count, empty_count
                    )
                )
            else:
                QMessageBox.information(
                    self, "Split selesai",
                    "{} titik berhasil dibagi menjadi {} layer IDsLS pada {} desa.\n\n"
                    "Semua hasil berada di satu folder QGIS: SPLIT.".format(
                        total_written, layer_count, len(desa_stats)
                    )
                )
            self._set_progress(100)

        except Exception as e:
            self.log.append("SPLIT ERROR: {}".format(e))
            QMessageBox.critical(self, "Split Titik Bangunan gagal", str(e))

    def choose_raster(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pilih peta scan georeference", "", "Raster (*.tif *.tiff *.jpg *.jpeg *.png *.bmp);;Semua file (*.*)")
        if not path: return
        layer = QgsRasterLayer(path, os.path.basename(path))
        if not layer.isValid():
            QMessageBox.warning(self, "Raster tidak valid", "File scan tidak dapat dibaca QGIS.")
            return
        QgsProject.instance().addMapLayer(layer, False)
        self.raster_combo.addItem(layer.name(), layer.id())
        self.raster_combo.setCurrentIndex(self.raster_combo.count()-1)
        self.log.append("SCAN: {}".format(path))

    def _ensure_status_field(self, field_name="flag_repair"):
        """Ensure a safe integer 0/1 status field exists for the reference QML.

        Loading the style must never make points disappear just because the source
        landmark layer has no flag_repair field yet. We add only the attribute
        column; feature count and geometry are untouched.
        """
        layer = self._selected_layer()
        if not layer:
            return None
        idx = layer.fields().indexOf(field_name)
        if idx >= 0:
            return field_name
        if not layer.isEditable():
            if not layer.startEditing():
                return None
        if not layer.dataProvider().addAttributes([QgsField(field_name, QVariant.Int)]):
            return None
        layer.updateFields()
        idx = layer.fields().indexOf(field_name)
        if idx < 0:
            return None
        for ft in layer.getFeatures():
            layer.changeAttributeValue(ft.id(), idx, 0)
        layer.triggerRepaint()
        self.log.append("STATUS: field '{}' dibuat otomatis dengan nilai awal 0. Feature dan geometry tidak berubah.".format(field_name))
        return field_name

    def _binary_status_field(self, preferred=None):
        """Return a real 0/1 status field suitable for cek_titik.qml.

        The reference QML categorizes on ``flag_repair``. Some production
        landmark layers do not carry that field and instead use another 0/1
        status column. Never apply the QML to a layer without a compatible
        status field because QGIS would render zero categories and make the
        points appear to disappear.
        """
        layer = self._selected_layer()
        if not layer:
            return None
        names = [f.name() for f in layer.fields()]
        ordered = []
        for name in (preferred, "flag_repair", "flag_position", "flag_repair_moved"):
            if name and name in names and name not in ordered:
                ordered.append(name)
        for name in names:
            low = name.lower()
            if name not in ordered and any(k in low for k in ("flag", "status", "cek", "repair", "posisi")):
                ordered.append(name)
        for name in ordered:
            vals=[]
            try:
                for ft in layer.getFeatures():
                    v=ft[name]
                    if v is not None and str(v).strip() != "":
                        vals.append(str(v).strip())
                    if len(vals) >= 1000:
                        break
            except Exception:
                vals=[]
            if vals and all(v in ("0", "1", "0.0", "1.0") for v in vals):
                return name
        return None

    @staticmethod
    def _qml_renderer_field(path):
        """Read the categorized renderer field from a QML without loading it."""
        try:
            import xml.etree.ElementTree as ET
            root=ET.parse(path).getroot()
            renderer=root.find("renderer-v2")
            if renderer is not None:
                return renderer.attrib.get("attr") or ""
        except Exception:
            pass
        return ""

    def load_style(self):
        layer = self._selected_layer()
        if not layer:
            QMessageBox.warning(self, "Pilih layer", "Pilih layer titik bangunan terlebih dahulu.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Load style titik bangunan", "", "QGIS Style (*.qml)")
        if not path: return

        original_renderer = None
        try:
            original_renderer = layer.renderer().clone()
        except Exception:
            pass

        temp_path = None
        try:
            qml_field = self._qml_renderer_field(path)
            status_field = self._binary_status_field(self.attr_combo.currentText())

            # If the QML expects flag_repair and the source has no binary status
            # field, create that field safely instead of refusing the style.
            # This is an additive schema change only: no feature is added/deleted
            # and no geometry is changed.
            load_path = path
            if qml_field and layer.fields().indexOf(qml_field) < 0:
                status_field = status_field or self._ensure_status_field(qml_field)
                if not status_field:
                    raise RuntimeError("Tidak dapat menyiapkan atribut status 0/1 untuk QML.")
                if status_field != qml_field:
                    text = open(path, "r", encoding="utf-8").read()
                    text = text.replace('attr="{}"'.format(qml_field), 'attr="{}"'.format(status_field), 1)
                    fd, temp_path = tempfile.mkstemp(prefix="sls_style_", suffix=".qml")
                    os.close(fd)
                    with open(temp_path, "w", encoding="utf-8") as fh:
                        fh.write(text)
                    load_path = temp_path
                    self.log.append("STYLE COMPATIBILITY: {} → {}".format(qml_field, status_field))

            if status_field and self.attr_combo.findText(status_field) < 0:
                self.attr_combo.addItem(status_field)
            if status_field:
                self.attr_combo.setCurrentText(status_field)

            result = layer.loadNamedStyle(load_path)
            if isinstance(result, tuple):
                bools=[v for v in result if isinstance(v,bool)]
                ok=bools[0] if bools else bool(result[0])
                message=" | ".join(str(v) for v in result if not isinstance(v,bool) and str(v).strip())
            else:
                ok=bool(result); message=""
            if not ok:
                raise RuntimeError(message or "QGIS tidak dapat menerapkan QML pada layer terpilih.")

            # Post-load safety check: a categorized renderer pointing to a
            # missing field would make every feature unmatched/invisible.
            renderer=layer.renderer()
            if hasattr(renderer, "classAttribute"):
                active_field=renderer.classAttribute()
                if active_field and layer.fields().indexOf(active_field) < 0:
                    if original_renderer is not None:
                        layer.setRenderer(original_renderer)
                    raise RuntimeError("QML dibatalkan: renderer mengacu field '{}' yang tidak ada pada layer. Titik dipertahankan dengan style sebelumnya.".format(active_field))

            layer.triggerRepaint()
            self.style_path.setText(os.path.basename(path))
            self.log.append("STYLE: berhasil dimuat → {}".format(path))
            self._layer_changed()
        except Exception as e:
            # Never leave the layer with a broken renderer after a failed load.
            try:
                if original_renderer is not None:
                    layer.setRenderer(original_renderer)
                    layer.triggerRepaint()
            except Exception:
                pass
            QMessageBox.warning(self, "Load style", str(e))
        finally:
            if temp_path:
                try: os.remove(temp_path)
                except Exception: pass

    # ------------------------------ raster detector ------------------------------
    def _open_gdal(self, raster):
        try:
            from osgeo import gdal
        except Exception as e:
            raise RuntimeError("GDAL Python tidak tersedia pada environment QGIS: {}".format(e))
        source = raster.source()
        ds = gdal.Open(source, gdal.GA_ReadOnly)
        if ds is None:
            uri = raster.dataProvider().dataSourceUri()
            ds = gdal.Open(uri, gdal.GA_ReadOnly)
        if ds is None:
            raise RuntimeError("GDAL tidak dapat membuka raster scan: {}".format(source))
        if ds.RasterCount < 1: raise RuntimeError("Raster tidak memiliki band.")
        return ds

    @staticmethod
    def _world_to_pixel(gt, x, y):
        a, b, c, d, e, f = gt
        det = b*f - c*e
        if abs(det) < 1e-15: raise RuntimeError("Geotransform raster tidak valid.")
        dx, dy = x-a, y-d
        return ((dx*f-dy*c)/det, (dy*b-dx*e)/det)

    @staticmethod
    def _pixel_to_world(gt, px, py):
        a,b,c,d,e,f=gt
        return (a+b*(px+0.5)+c*(py+0.5), d+e*(px+0.5)+f*(py+0.5))

    def _gray(self, bands, width, height):
        """Convert raster band byte buffers to a pure-Python grayscale matrix.
        This deliberately avoids NumPy/SciPy so AUTO TITIK BANGUNAN does not
        trigger Windows blocking of numpy's mtrand binary module.
        """
        import struct
        def unpack_band(data):
            if not data or len(data) < width*height*4:
                raise RuntimeError("Raster band gagal dibaca sebagai Float32.")
            vals = struct.unpack('<{}f'.format(width*height), data[:width*height*4])
            return vals
        vals = [unpack_band(b) for b in bands]
        if len(vals) == 1:
            return [list(vals[0][y*width:(y+1)*width]) for y in range(height)]
        r,g,b = vals[0], vals[1], vals[2]
        return [[0.299*r[y*width+x] + 0.587*g[y*width+x] + 0.114*b[y*width+x]
                 for x in range(width)] for y in range(height)]

    def _components(self, mask):
        """8-connected components with a lightweight boundary/perimeter metric.

        The extra metric is important for AUTO TITIK BANGUNAN: a filled black
        survey dot is compact and round, while labels, digits and map lines are
        usually elongated or have a much lower circularity.
        """
        h=len(mask); w=len(mask[0]) if h else 0; seen=set(); out=[]
        for y in range(h):
            for x in range(w):
                if not mask[y][x] or (y,x) in seen: continue
                stack=[(y,x)]; seen.add((y,x)); area=0; sx=sy=0; minx=maxx=x; miny=maxy=y; perimeter=0
                while stack:
                    yy,xx=stack.pop(); area+=1; sx+=xx; sy+=yy
                    minx=min(minx,xx); maxx=max(maxx,xx); miny=min(miny,yy); maxy=max(maxy,yy)
                    # 4-neighbour edge count gives a stable perimeter estimate.
                    for ey,ex in ((-1,0),(1,0),(0,-1),(0,1)):
                        ny,nx=yy+ey,xx+ex
                        if ny<0 or ny>=h or nx<0 or nx>=w or not mask[ny][nx]:
                            perimeter += 1
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if not dx and not dy: continue
                            ny,nx=yy+dy,xx+dx
                            if 0<=ny<h and 0<=nx<w and mask[ny][nx] and (ny,nx) not in seen:
                                seen.add((ny,nx)); stack.append((ny,nx))
                if area:
                    circularity=(4.0*math.pi*area/(perimeter*perimeter)) if perimeter else 0.0
                    compact=area/float(max(1,(maxx-minx+1)*(maxy-miny+1)))
                    aspect=min(maxx-minx+1,maxy-miny+1)/float(max(maxx-minx+1,maxy-miny+1))
                    out.append((area, sx/area, sy/area, maxx-minx+1, maxy-miny+1, circularity, compact, aspect))
        return out

    @staticmethod
    def _safe_pointxy(x, y):
        """Create QgsPointXY with strict native Python floats.

        QGIS 3.44 can reject SIP-wrapped/tuple/numeric values when an overloaded
        constructor receives an unexpected type.  AUTO TITIK BANGUNAN keeps all
        raster-derived coordinates normalized here before crossing the SIP API.
        """
        try:
            if hasattr(x, "x") and callable(x.x):
                x = x.x()
            if hasattr(y, "y") and callable(y.y):
                y = y.y()
            if isinstance(x, (tuple, list)) and len(x) == 2:
                x = x[0]
            if isinstance(y, (tuple, list)) and len(y) == 2:
                y = y[1]
            return QgsPointXY(float(x), float(y))
        except Exception as e:
            raise TypeError("Koordinat titik tidak valid: x={!r}, y={!r} ({})".format(x, y, e))

    def _candidates(self, ds, gt, x, y, raster_crs, layer_crs):
        """Detect black ink dots around one landmark and return ranked targets.

        The scan dots are normally much larger than a 1-2 pixel point.  Earlier
        versions rejected them when their connected-component area exceeded the
        small default max size (120 px).  This detector therefore uses the UI
        limits as a guide, but also applies a compactness/shape test so large
        text and map lines are rejected while genuine round ink dots survive.
        """
        try:
            from osgeo import gdal
        except Exception as e:
            raise RuntimeError("GDAL Python tidak tersedia pada environment QGIS: {}".format(e))

        p = self._safe_pointxy(x, y)
        if layer_crs != raster_crs:
            p = QgsCoordinateTransform(layer_crs, raster_crs, QgsProject.instance()).transform(p)
        px, py = self._world_to_pixel(gt, p.x(), p.y())

        pix_x = max(abs(gt[1]), 1e-12)
        pix_y = max(abs(gt[5]), 1e-12)
        rp = float(self.radius.value())

        # Search a little wider than the acceptance radius.  This makes the
        # identification resilient to small landmark shifts while still using
        # the configured radius as the final MATCH tolerance.
        search_map = max(rp * 4.0, rp + max(pix_x, pix_y) * 32.0)
        rx = max(8, int(math.ceil(search_map / pix_x)))
        ry = max(8, int(math.ceil(search_map / pix_y)))
        x0 = max(0, int(math.floor(px)) - rx)
        y0 = max(0, int(math.floor(py)) - ry)
        x1 = min(ds.RasterXSize, int(math.floor(px)) + rx + 1)
        y1 = min(ds.RasterYSize, int(math.floor(py)) + ry + 1)
        if x1 <= x0 or y1 <= y0:
            return []

        width = x1 - x0
        height = y1 - y0
        band_count = min(3, int(ds.RasterCount))
        bands = []
        for bi in range(1, band_count + 1):
            band = ds.GetRasterBand(bi)
            data = band.ReadRaster(xoff=x0, yoff=y0, xsize=width, ysize=height,
                                   buf_xsize=width, buf_ysize=height,
                                   buf_type=gdal.GDT_Float32)
            if data is None:
                return []
            bands.append(data)
        if not bands:
            return []

        gray = self._gray(bands, width, height)
        # Adaptive thresholds: scan ink may be dark brown/grey rather than pure black.
        base_threshold = int(self.dark.value())
        thresholds = []
        for t in (base_threshold, min(base_threshold + 35, 180), min(base_threshold + 70, 210)):
            if t not in thresholds:
                thresholds.append(t)

        min_area = max(1, int(self.min_px.value()))
        ui_max = max(min_area + 1, int(self.max_px.value()))
        max_area = max(ui_max, 20000)

        unique = {}
        for threshold in thresholds:
            mask = [[v <= threshold for v in row] for row in gray]
            comps = self._components(mask)
            for area, cx, cy, bw, bh in comps:
                if area < min_area or area > max_area:
                    continue
                if bw > 140 or bh > 140:
                    continue
                compact = area / float(max(1, bw * bh))
                if compact < 0.28:
                    continue
                aspect = min(bw, bh) / float(max(bw, bh))
                if aspect < 0.42:
                    continue
                wx, wy = self._pixel_to_world(gt, x0 + cx, y0 + cy)
                dist = math.hypot(wx - p.x(), wy - p.y())
                if dist > search_map:
                    continue
                threshold_penalty = max(0, threshold - base_threshold) * 0.01 * max(rp, 1.0)
                shape_penalty = (1.0 - compact) * max(rp, 1.0) * 0.45
                aspect_penalty = (1.0 - aspect) * max(rp, 1.0) * 0.25
                score = dist + shape_penalty + aspect_penalty + threshold_penalty
                key = (round(x0 + cx, 1), round(y0 + cy, 1))
                item = (score, wx, wy, area, bw, bh, dist, compact)
                prev = unique.get(key)
                if prev is None or item[0] < prev[0]:
                    unique[key] = item

        candidates = list(unique.values())
        candidates.sort(key=lambda z: (z[0], z[6]))
        return candidates

    def _to_layer_point(self, raster_x, raster_y, raster_crs, layer_crs):
        p=self._safe_pointxy(raster_x, raster_y)
        if raster_crs != layer_crs:
            p=QgsCoordinateTransform(raster_crs,layer_crs,QgsProject.instance()).transform(p)
        return p

    def _clear_marks(self):
        """Remove Auto Titik highlight markers, including markers left by a
        previous plugin instance/reload.  Only our soft-yellow rubber bands
        are targeted; vector layer features are never deleted.
        """
        # Current plugin instance markers.
        for rb in list(getattr(self, "_rubber_bands", [])):
            try:
                rb.reset(True)
                rb.hide()
            except Exception:
                pass
        self._rubber_bands = []

        # Markers created by an older/reloaded instance can survive in the
        # map canvas even though its Python object is no longer referenced.
        # Identify the exact soft-yellow style used by Auto Titik and clear
        # those rubber bands as well.
        try:
            from qgis.gui import QgsRubberBand
            canvas = self.iface.mapCanvas()
            scene = canvas.scene()
            if scene is not None:
                for item in list(scene.items()):
                    if not isinstance(item, QgsRubberBand):
                        continue
                    try:
                        c = item.color()
                        if (c.red(), c.green(), c.blue(), c.alpha()) == (255, 224, 120, 210):
                            item.reset(True)
                            item.hide()
                            if hasattr(item, "deleteLater"):
                                item.deleteLater()
                    except Exception:
                        pass
            canvas.refresh()
        except Exception:
            pass

    def _mark_changes(self, layer, changes):
        self._clear_marks()
        try:
            from qgis.gui import QgsRubberBand
            for ch in changes:
                p=self._safe_pointxy(ch['new_x'], ch['new_y'])
                rb=QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.PointGeometry)
                rb.setColor(QColor(255, 224, 120, 210))
                rb.setFillColor(QColor(255, 235, 150, 170))
                rb.setWidth(3); rb.setIconSize(9); rb.setIcon(QgsRubberBand.ICON_CIRCLE)
                rb.setToGeometry(QgsGeometry.fromPointXY(p), layer)
                self._rubber_bands.append(rb)
        except Exception:
            pass

    def _detect_black_dot_local(self, ds, gt, raster_point):
        """Find the actual filled black survey dot around one building point.

        This is intentionally local: each source point gets its own small scan
        window.  The detector does NOT choose an arbitrary dark pixel from the
        whole raster.  It looks for a compact, nearly round, filled component and
        returns the centre of that component in raster coordinates.
        """
        try:
            from osgeo import gdal
        except Exception as e:
            raise RuntimeError("GDAL Python tidak tersedia pada environment QGIS: {}".format(e))

        px, py = self._world_to_pixel(gt, float(raster_point.x()), float(raster_point.y()))
        pix_x=max(abs(float(gt[1])),1e-12); pix_y=max(abs(float(gt[5])),1e-12)
        rp=max(float(self.radius.value()),1e-9)
        # Search wider than the final match radius.  The final decision below
        # still requires the detected dot to be inside the configured radius.
        search_map=max(rp*4.0, rp+max(pix_x,pix_y)*24.0)
        rx=max(10,int(math.ceil(search_map/pix_x)))
        ry=max(10,int(math.ceil(search_map/pix_y)))
        x0=max(0,int(math.floor(px))-rx); y0=max(0,int(math.floor(py))-ry)
        x1=min(ds.RasterXSize,int(math.floor(px))+rx+1); y1=min(ds.RasterYSize,int(math.floor(py))+ry+1)
        if x1<=x0 or y1<=y0: return []

        width=x1-x0; height=y1-y0
        bands=[]
        band_count=min(3,int(ds.RasterCount))
        for bi in range(1,band_count+1):
            data=ds.GetRasterBand(bi).ReadRaster(xoff=x0,yoff=y0,xsize=width,ysize=height,
                                                   buf_xsize=width,buf_ysize=height,buf_type=gdal.GDT_Float32)
            if data is None: return []
            bands.append(data)
        gray=self._gray(bands,width,height)
        base=int(self.dark.value())
        thresholds=[]
        for t in (base,min(base+20,180),min(base+40,200)):
            if t not in thresholds: thresholds.append(t)

        min_area=max(3,int(self.min_px.value()))
        ui_max=max(min_area+1,int(self.max_px.value()))
        # The UI maximum remains respected, but a huge value must not make
        # labels/text compete with the survey dots.  A practical dot diameter
        # ceiling is derived from the configured maximum area.
        max_area=min(ui_max,50000)
        candidates={}
        for threshold in thresholds:
            mask=[[v<=threshold for v in row] for row in gray]
            for comp in self._components(mask):
                area,cx,cy,bw,bh,circularity,compact,aspect=comp
                if area<min_area or area>max_area: continue
                # A genuine filled dot is compact, round and not paper-thin.
                if bw<3 or bh<3 or bw>160 or bh>160: continue
                if aspect<0.55 or compact<0.48 or circularity<0.28: continue
                wx,wy=self._pixel_to_world(gt,x0+cx,y0+cy)
                dist=math.hypot(float(wx)-float(raster_point.x()),float(wy)-float(raster_point.y()))
                if dist>search_map: continue
                # Strong preference for round/filled components, then distance.
                score=dist + (1.0-circularity)*rp*0.8 + (1.0-compact)*rp*0.8 + (1.0-aspect)*rp*0.3
                key=(round(float(x0+cx),1),round(float(y0+cy),1))
                item=(score,float(wx),float(wy),float(dist),int(area),int(bw),int(bh),float(circularity),float(compact),int(threshold))
                old=candidates.get(key)
                if old is None or item[0]<old[0]: candidates[key]=item
        result=sorted(candidates.values(),key=lambda z:(z[0],z[3]))
        return result

    # ------------------------------ workflow ------------------------------
    def _detect_targets_once(self, ds, gt, points, raster_crs):
        """Detect compact dark targets once for the whole landmark extent.

        Previous versions reopened/read a raster window and ran connected
        components for every landmark.  With 244 landmarks that meant hundreds
        of raster reads and repeated component scans.  This method reads the
        required map region once, detects the black ink targets once, and lets
        identify() perform the cheap point-to-target matching afterwards.
        """
        try:
            from osgeo import gdal
        except Exception as e:
            raise RuntimeError("GDAL Python tidak tersedia pada environment QGIS: {}".format(e))
        if not points:
            return []

        pix_x=max(abs(float(gt[1])), 1e-12)
        pix_y=max(abs(float(gt[5])), 1e-12)
        rp=float(self.radius.value())
        search_map=max(rp*4.0, rp+max(pix_x,pix_y)*32.0)
        rx=max(8, int(math.ceil(search_map/pix_x)))
        ry=max(8, int(math.ceil(search_map/pix_y)))

        xs=[p[0] for p in points]; ys=[p[1] for p in points]
        pxs=[]; pys=[]
        for x,y in zip(xs,ys):
            px,py=self._world_to_pixel(gt,float(x),float(y)); pxs.append(px); pys.append(py)
        x0=max(0, int(math.floor(min(pxs)))-rx)
        y0=max(0, int(math.floor(min(pys)))-ry)
        x1=min(ds.RasterXSize, int(math.floor(max(pxs)))+rx+1)
        y1=min(ds.RasterYSize, int(math.floor(max(pys)))+ry+1)
        if x1<=x0 or y1<=y0:
            return []

        width=x1-x0; height=y1-y0
        band_count=min(3,int(ds.RasterCount)); bands=[]
        for bi in range(1,band_count+1):
            band=ds.GetRasterBand(bi)
            data=band.ReadRaster(xoff=x0,yoff=y0,xsize=width,ysize=height,
                                 buf_xsize=width,buf_ysize=height,buf_type=gdal.GDT_Float32)
            if data is None:
                return []
            bands.append(data)
        gray=self._gray(bands,width,height)

        base_threshold=int(self.dark.value())
        thresholds=[]
        for t in (base_threshold,min(base_threshold+35,180),min(base_threshold+70,210)):
            if t not in thresholds: thresholds.append(t)
        min_area=max(1,int(self.min_px.value()))
        ui_max=max(min_area+1,int(self.max_px.value()))
        max_area=max(ui_max,20000)

        unique={}
        for threshold in thresholds:
            mask=[[v<=threshold for v in row] for row in gray]
            comps=self._components(mask)
            for area,cx,cy,bw,bh,circularity,compact,aspect in comps:
                if area<min_area or area>max_area or bw>160 or bh>160: continue
                # Survey noktah harus berupa massa tinta yang padat dan relatif bulat.
                # Threshold global dibuat sama ketatnya dengan detector lokal agar
                # tulisan/garis peta tidak ikut menjadi target.
                if bw<3 or bh<3: continue
                if compact<0.48: continue
                if aspect<0.55: continue
                if circularity<0.28: continue
                wx,wy=self._pixel_to_world(gt,x0+cx,y0+cy)
                key=(round(float(x0+cx),1),round(float(y0+cy),1))
                item=(float(wx),float(wy),float(area),float(bw),float(bh),float(compact),float(aspect))
                old=unique.get(key)
                if old is None or threshold < old[7]:
                    unique[key]=item+(int(threshold),)

        targets=list(unique.values())
        self.log.append("DETECTED COMPACT TARGETS: {} | raster region: {}x{} px".format(len(targets),width,height))
        return targets

    def _toggle_auto_titik_lock(self):
        if not self._auto_titik_locked:
            self._set_auto_titik_locked(True)
            return
        dlg = QDialog(None)
        dlg.setWindowTitle("AUTO TITIK BANGUNAN • UNLOCK")
        dlg.setWindowFlags(Qt.Dialog | Qt.WindowStaysOnTopHint | Qt.WindowTitleHint | Qt.WindowSystemMenuHint)
        dlg.setModal(True)
        dlg.setMinimumWidth(360)
        lay = QVBoxLayout(dlg)
        title = QLabel("🔒  FITUR TERKUNCI")
        title.setStyleSheet("font-size:12pt;font-weight:800;color:#17365D;")
        lay.addWidget(title)
        note = QLabel("Masukkan password untuk menggunakan AUTO TITIK BANGUNAN.")
        note.setWordWrap(True)
        lay.addWidget(note)
        edit = QLineEdit()
        edit.setEchoMode(QLineEdit.Password)
        edit.setPlaceholderText("Password")
        edit.setMinimumHeight(34)
        lay.addWidget(edit)
        buttons = QHBoxLayout()
        cancel = QPushButton("BATAL")
        unlock = QPushButton("🔓 UNLOCK")
        unlock.setDefault(True)
        buttons.addStretch(1); buttons.addWidget(cancel); buttons.addWidget(unlock)
        lay.addLayout(buttons)
        cancel.clicked.connect(dlg.reject)
        def do_unlock():
            if edit.text() == self._auto_titik_password:
                self._set_auto_titik_locked(False)
                dlg.accept()
            else:
                QMessageBox.warning(dlg, "Password salah", "Password AUTO TITIK BANGUNAN tidak benar.")
                edit.selectAll(); edit.setFocus()
        unlock.clicked.connect(do_unlock)
        edit.returnPressed.connect(do_unlock)
        edit.setFocus()
        dlg.exec_()

    def _set_auto_titik_locked(self, locked):
        self._auto_titik_locked = bool(locked)
        self._apply_auto_titik_lock_ui()

    def _apply_auto_titik_lock_ui(self):
        locked = bool(getattr(self, "_auto_titik_locked", True))
        if hasattr(self, "btn_auto_lock"):
            self.btn_auto_lock.setText("🔒  LOCKED" if locked else "🔓  UNLOCKED")
            self.btn_auto_lock.setToolTip("Klik untuk memasukkan password." if locked else "Klik untuk mengunci kembali.")
        if hasattr(self, "auto_titik_lock_badge"):
            self.auto_titik_lock_badge.setText("🔒 LOCKED" if locked else "🔓 UNLOCKED")
        names = (
            "btn_style", "btn_raster", "layer_combo", "raster_combo", "attr_combo",
            "radius", "dark", "min_px", "max_px", "preview_only",
            "btn_identify", "btn_generate", "btn_clear_highlight",
            "btn_undo_generate", "btn_redo_generate", "btn_refresh"
        )
        for name in names:
            w = getattr(self, name, None)
            if w is not None:
                w.setEnabled(not locked)
        # SPLIT is deliberately independent from the AUTO TITIK lock.
        if hasattr(self, "split_field_combo"):
            self.split_field_combo.setEnabled(True)
        if hasattr(self, "btn_split"):
            self.btn_split.setEnabled(True)
        if hasattr(self, "btn_split_refresh"):
            self.btn_split_refresh.setEnabled(True)

    def _auto_titik_unlocked(self):
        if self._auto_titik_locked:
            QMessageBox.information(self, "AUTO TITIK BANGUNAN", "Fitur terkunci. Klik tombol LOCKED lalu masukkan password.")
            return False
        return True

    def identify(self):
        if not self._auto_titik_unlocked():
            return
        """Scan the georeferenced raster once and match each building point 1:1
        to the centre of a compact black ink dot."""
        layer = self._selected_layer()
        raster = self._selected_raster()
        if not layer or not raster:
            QMessageBox.warning(
                self, "Input belum lengkap",
                "Pilih layer titik bangunan dan peta scan georeference."
            )
            return

        try:
            ds = self._open_gdal(raster)
            gt = ds.GetGeoTransform()
            total = layer.featureCount()
            self._set_progress(0)
            self.table.setRowCount(0)
            self._pending_rows = []
            self.log.clear()
            self.log.append(
                "IDENTIFIKASI NOKTAH HITAM: {} feature → {}".format(
                    total, raster.name()
                )
            )
            self.log.append(
                "MODE: scan area georeference → deteksi komponen tinta hitam "
                "compact/round → centroid komponen = pusat noktah."
            )
            self.log.append(
                "MATCH 1:1: satu titik bangunan hanya boleh memakai satu noktah hitam."
            )

            features = []
            for ft in layer.getFeatures():
                geom = ft.geometry()
                if geom is None or geom.isEmpty():
                    continue
                try:
                    p = geom.asPoint()
                except Exception:
                    continue
                lp = self._safe_pointxy(float(p.x()), float(p.y()))
                rpnt = lp
                if layer.crs() != raster.crs():
                    rpnt = QgsCoordinateTransform(
                        layer.crs(), raster.crs(), QgsProject.instance()
                    ).transform(lp)
                features.append(
                    (ft.id(), lp.x(), lp.y(), float(rpnt.x()), float(rpnt.y()))
                )

            if not features:
                QMessageBox.warning(self, "Identifikasi", "Tidak ada geometry titik yang valid.")
                return

            # One raster read / component detection for the complete working area.
            points_raster = [(r[3], r[4]) for r in features]
            targets = self._detect_targets_once(ds, gt, points_raster, raster.crs())

            if not targets:
                self.log.append("NO TARGET: tidak ditemukan noktah hitam compact pada area scan.")
                rows = [
                    (fid, "NO MATCH", None, ox, oy, ox, oy, 0)
                    for fid, ox, oy, rx, ry in features
                ]
                self._populate(rows)
                self._pending_rows = rows
                self.summary.setText(
                    "Total: {} | MATCH: 0 | REVIEW: 0 | NO MATCH: {} | Feature tetap: {}".format(
                        total, len(rows), total
                    )
                )
                self._set_progress(100)
                return

            self.log.append("TARGET NOKTAH HITAM TERDETEKSI: {}".format(len(targets)))

            # Build a STRICT local candidate list for every building point.
            # We deliberately use only compact/round black components near the
            # source point.  This prevents dark roofs, labels and map lines from
            # competing with the actual survey noktah.
            candidate_lists = {}
            radius = float(self.radius.value())
            pix_x = max(abs(float(gt[1])), 1e-12)
            pix_y = max(abs(float(gt[5])), 1e-12)
            hard_limit = max(radius, max(pix_x, pix_y) * 18.0)

            for fi, (fid, ox, oy, rx, ry) in enumerate(features):
                local = []
                for ti, t in enumerate(targets):
                    wx, wy, area, bw, bh, compact, aspect, threshold = t
                    d_raster = math.hypot(float(wx) - rx, float(wy) - ry)
                    if d_raster > hard_limit:
                        continue
                    npnt = self._to_layer_point(
                        float(wx), float(wy), raster.crs(), layer.crs()
                    )
                    dist = math.hypot(
                        float(npnt.x()) - float(ox),
                        float(npnt.y()) - float(oy)
                    )
                    if dist > radius:
                        continue
                    # Distance dominates. Shape terms are tie-breakers that
                    # favour a real filled dot over a text fragment.
                    shape = (1.0 - float(compact)) * radius * 0.45
                    shape += (1.0 - float(aspect)) * radius * 0.20
                    threshold_penalty = max(
                        0.0, float(threshold) - float(self.dark.value())
                    ) * 0.005 * max(radius, 1.0)
                    score = dist + shape + threshold_penalty
                    local.append((score, dist, fi, ti, npnt))
                local.sort(key=lambda z: (z[0], z[1], z[3]))
                candidate_lists[fi] = local[:12]

            # Resolve conflicts iteratively. If two building points want the
            # same black dot, the point with the lower cost keeps it and the
            # other point tries its next candidate. This is more reliable than
            # a single global greedy sort when points are close together.
            next_choice = {fi: 0 for fi in range(len(features))}
            selected = {}
            used_targets = set()
            pending = set(fi for fi in range(len(features)) if candidate_lists.get(fi))
            while pending:
                claims = {}
                retry = set()
                for fi in sorted(pending):
                    lst = candidate_lists.get(fi, [])
                    pos = next_choice.get(fi, 0)
                    if pos >= len(lst):
                        continue
                    cand = lst[pos]
                    claims.setdefault(cand[3], []).append(cand)
                pending.clear()
                for ti, claimants in claims.items():
                    winner = min(claimants, key=lambda z: (z[0], z[1], z[2]))
                    fi = winner[2]
                    selected[fi] = winner
                    used_targets.add(ti)
                    for loser in claimants:
                        lfi = loser[2]
                        if lfi != fi:
                            next_choice[lfi] = next_choice.get(lfi, 0) + 1
                            if next_choice[lfi] < len(candidate_lists.get(lfi, [])):
                                pending.add(lfi)

            rows = []
            match_count = review_count = no_match = 0
            for idx, (fid, ox, oy, rx, ry) in enumerate(features):
                if idx not in selected:
                    rows.append((fid, "NO MATCH", None, ox, oy, ox, oy, 0))
                    no_match += 1
                else:
                    score, dist, fi, ti, npnt = selected[idx]
                    nx, ny = float(npnt.x()), float(npnt.y())
                    # All accepted candidates are inside the requested radius.
                    status = "MATCH"
                    match_count += 1
                    rows.append((fid, status, dist, ox, oy, nx, ny, 1))
                    if idx < 20:
                        t = targets[ti]
                        self.log.append(
                            "  FID {} → NOKTAH #{} pusat ({:.3f}, {:.3f}) | "
                            "d={:.3f} | area={} | compact={:.2f} | aspect={:.2f}".format(
                                fid, ti + 1, nx, ny, dist, int(t[2]),
                                float(t[5]), float(t[6])
                            )
                        )
                self._set_progress(int((idx + 1) * 100 / max(1, len(features))))
                if idx % 10 == 0:
                    QApplication.processEvents()

            self._populate(rows)
            self._pending_rows = rows
            self.summary.setText(
                "Total: {} | MATCH: {} | REVIEW: {} | NO MATCH: {} | "
                "Feature tetap: {} | Target unik: {}".format(
                    total, match_count, review_count, no_match, total, len(targets)
                )
            )
            self.log.append(
                "SELESAI: {} MATCH | {} REVIEW | {} NO MATCH | {} target unik.".format(
                    match_count, review_count, no_match, len(targets)
                )
            )
            self.log.append(
                "PRINSIP UPDATE: geometry dipindahkan ke CENTROID/PUSAT NOKTAH HITAM, "
                "bukan ke pixel hitam terdekat."
            )
            self._set_progress(100)

        except Exception as e:
            self._set_progress(0)
            QMessageBox.critical(self, "Identifikasi gagal", str(e))

    def _populate(self, rows):
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            fid,status,dist,ox,oy,nx,ny,count=r
            vals=[str(fid),status,"—" if dist is None else "{:.3f}".format(dist),"{:.3f}".format(nx-ox),"{:.3f}".format(ny-oy),"{} kandidat".format(count)]
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(v))
            if status=="MATCH":
                bg=QColor(230,247,238)
            elif status=="REVIEW":
                bg=QColor(255,247,214)
            else: bg=QColor(248,228,228)
            for j in range(6): self.table.item(i,j).setBackground(bg)

    def clear_highlight(self):
        if not self._auto_titik_unlocked():
            return
        """Remove only the soft-yellow visual marks; never delete features."""
        self._clear_marks()
        try:
            layer = self._selected_layer()
            if layer:
                layer.triggerRepaint()
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
        self.log.append("CLEAR HIGHLIGHT: tanda kuning dihapus. Feature tetap utuh.")

    def undo_generate(self):
        if not self._auto_titik_unlocked():
            return
        """Undo the last AUTO TITIK update without deleting any feature."""
        layer = self._selected_layer()
        if not layer or not self._last_changes:
            QMessageBox.information(self, "UNDO", "Belum ada perubahan Generate yang dapat di-Undo.")
            return
        try:
            layer.startEditing()
            layer.beginEditCommand("UNDO AUTO TITIK BANGUNAN")
            for ch in self._last_changes:
                fid = ch['fid']
                ft = layer.getFeature(fid)
                if not ft.isValid():
                    continue
                layer.changeGeometry(fid, QgsGeometry(ch['old_geom']))
                attr_name = ch.get('attr_name')
                if attr_name:
                    idx = layer.fields().indexOf(attr_name)
                    if idx >= 0 and ch.get('old_attr') is not None:
                        layer.changeAttributeValue(fid, idx, ch.get('old_attr'))
            layer.endEditCommand()
            self._redo_changes = list(self._last_changes)
            self._last_changes = []
            self._clear_marks()
            layer.triggerRepaint(); self.iface.mapCanvas().refresh()
            self.log.append("UNDO: {} perubahan geometry/atribut dikembalikan ke posisi sebelum Generate.".format(len(self._redo_changes)))
            self.summary.setText("UNDO: perubahan Generate terakhir dikembalikan | Feature tetap: {}".format(layer.featureCount()))
        except Exception as e:
            try: layer.destroyEditCommand()
            except Exception: pass
            QMessageBox.critical(self, "UNDO gagal", str(e))

    def redo_generate(self):
        if not self._auto_titik_unlocked():
            return
        """Redo the last AUTO TITIK update after our custom Undo."""
        layer = self._selected_layer()
        if not layer or not self._redo_changes:
            QMessageBox.information(self, "REDO", "Belum ada perubahan Generate yang dapat di-Redo.")
            return
        try:
            layer.startEditing()
            layer.beginEditCommand("REDO AUTO TITIK BANGUNAN")
            attr_cache = {}
            attr = self.attr_combo.currentText()
            if attr.startswith('('): attr = None
            for ch in self._redo_changes:
                fid = ch['fid']
                ft = layer.getFeature(fid)
                if not ft.isValid():
                    continue
                newgeom = QgsGeometry.fromPointXY(self._safe_pointxy(ch['new_x'], ch['new_y']))
                layer.changeGeometry(fid, newgeom)
                if attr:
                    idx = layer.fields().indexOf(attr)
                    if idx >= 0:
                        try:
                            if str(ft[attr]).strip() in ('1','1.0'):
                                layer.changeAttributeValue(fid, idx, 0)
                        except Exception:
                            pass
            layer.endEditCommand()
            self._last_changes = list(self._redo_changes)
            self._redo_changes = []
            self._mark_changes(layer, self._last_changes)
            layer.triggerRepaint(); self.iface.mapCanvas().refresh()
            self.log.append("REDO: {} perubahan Generate diterapkan kembali.".format(len(self._last_changes)))
            self.summary.setText("REDO: {} titik diterapkan kembali | Feature tetap: {} | Highlight kuning aktif".format(len(self._last_changes), layer.featureCount()))
        except Exception as e:
            try: layer.destroyEditCommand()
            except Exception: pass
            QMessageBox.critical(self, "REDO gagal", str(e))

    def generate(self):
        if not self._auto_titik_unlocked():
            return
        layer=self._selected_layer(); raster=self._selected_raster()
        if not layer or not raster:
            QMessageBox.warning(self,"Input belum lengkap","Pilih layer titik bangunan dan peta scan georeference.")
            return
        try:
            if not hasattr(self,'_pending_rows') or not self._pending_rows:
                self.identify()
            rows=getattr(self,'_pending_rows',[])
            if not rows: return
            matches=[r for r in rows if r[1]=="MATCH"]
            if self.preview_only.isChecked():
                self.log.append("PREVIEW MODE: tidak ada geometry/atribut yang diubah.")
                return
            attr=self.attr_combo.currentText()
            if attr.startswith('('): attr=None
            ds=self._open_gdal(raster); layer.startEditing()
            layer.beginEditCommand("AUTO TITIK BANGUNAN - UPDATE LANDMARK")
            changes=[]
            try:
                for i,r in enumerate(matches,1):
                    fid,_,dist,ox,oy,nx,ny,_=r
                    ft=layer.getFeature(fid)
                    if not ft.isValid(): continue
                    oldgeom=QgsGeometry(ft.geometry())
                    newgeom=QgsGeometry.fromPointXY(self._safe_pointxy(nx, ny))
                    if layer.changeGeometry(fid,newgeom):
                        if attr:
                            try:
                                val=ft[attr]
                                if str(val).strip() in ('1','1.0'):
                                    layer.changeAttributeValue(fid,layer.fields().indexOf(attr),0)
                            except Exception: pass
                        old_attr_value = None
                        if attr:
                            try:
                                old_attr_value = ft[attr]
                            except Exception:
                                old_attr_value = None
                        changes.append({'fid':fid,'old_geom':oldgeom,'old_attr':old_attr_value,'attr_name':attr,'new_x':nx,'new_y':ny,'dist':dist})
                    self._set_progress(int(i*100/max(1,len(matches))))
                    if i%25==0: QApplication.processEvents()
                layer.endEditCommand()
            except Exception:
                layer.destroyEditCommand(); raise
            # Post-update verification: every changed feature must now be at the
            # target coordinate recorded during identification.  This is a geometry
            # update only; no feature is created, deleted, or duplicated.
            verified = 0
            for ch in changes:
                ft2 = layer.getFeature(ch['fid'])
                if ft2.isValid() and not ft2.geometry().isEmpty():
                    q = ft2.geometry().asPoint()
                    err = math.hypot(q.x() - ch['new_x'], q.y() - ch['new_y'])
                    if err <= 1e-8:
                        verified += 1
            layer.triggerRepaint(); self.iface.mapCanvas().refresh()
            self._last_changes=changes
            self._redo_changes=[]
            self._mark_changes(layer,changes)
            self.summary.setText("UPDATED: {} titik | Tidak diubah: {} | Jumlah feature tetap: {} | Highlight perubahan: kuning soft".format(len(changes),layer.featureCount()-len(changes),layer.featureCount()))
            self.log.append("UPDATE BERHASIL: {} titik diposisikan ulang; verifikasi geometry {}/{} OK. Atribut 1 → 0 hanya pada titik yang berhasil diperbaiki.".format(len(changes), verified, len(changes)))
            self.log.append("Tidak ada feature ditambah/dihapus. Layer tetap {} feature.".format(layer.featureCount()))
            QMessageBox.information(self,"AUTO TITIK BANGUNAN selesai","{} titik berhasil diperbarui.\n\nJumlah feature tetap: {}\nPerubahan ditandai kuning soft.\n\nLayer masih dalam edit mode agar Anda dapat review/Undo sebelum Save.".format(len(changes),layer.featureCount()))
        except Exception as e:
            try: layer.destroyEditCommand()
            except Exception: pass
            QMessageBox.critical(self,"Update gagal",str(e))
