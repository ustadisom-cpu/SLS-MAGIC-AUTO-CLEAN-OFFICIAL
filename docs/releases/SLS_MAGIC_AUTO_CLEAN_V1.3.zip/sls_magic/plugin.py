from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QSize
from .core import Model3Dialog
import os

class SlsMagicPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QAction(QIcon(icon_path), "SLS MAGIC AUTO-CLEAN", self.iface.mainWindow())
        self.action.setIconVisibleInMenu(True)
        self.action.setToolTip("Open SLS MAGIC AUTO-CLEAN")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&SLS MAGIC", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&SLS MAGIC", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action.deleteLater()
            self.action = None
        self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = Model3Dialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
